# Dokumentacja Projektowa: System EZD RP (Elektroniczne Zarządzanie Dokumentacją)

## 1. Przegląd Projektu

### 1.1 Nazwa systemu
**EZD RP** - Elektroniczne Zarządzanie Dokumentacją w Rzeczypospolitej Polskiej

### 1.2 Opis systemu
EZD RP to bezpłatny system teleinformatyczny do elektronicznego zarządzania dokumentacją, dedykowany podmiotom publicznym. System został opracowany w celu usprawnienia i optymalizacji wewnętrznych procesów administracji publicznej, zapewniając bezpieczeństwo i precyzyjne wykonywanie zadań kancelaryjnych oraz archiwalnych.

### 1.3 Cel systemu
- Cyfryzacja procesów kancelaryjnych w administracji publicznej
- Usprawnienie przepływu dokumentów w organizacji
- Zapewnienie zgodności z przepisami (JRWA - Jednolity Rzeczowy Wykaz Akt)
- Wsparcie postępu cyfrowego w sektorze publicznym

### 1.4 Właściciel/Operator
Ministerstwo Cyfryzacji / Kancelaria Premiera / Narodowe Centrum Badń i Rozwoju (NASK)

---

## 2. Wersja Demonstracyjna (Demo EZD RP)

### 2.1 Dostępność
- **Data uruchomienia:** 1 czerwca 2023 r.
- **Adres demo:** https://ezdrp-web.demo.ezdrp.gov.pl/
- **Model dostępu:** Chmura (SaaS) - nie wymaga instalacji serwerowej

### 2.2 Zasady korzystania z Demo
| Parametr | Wartość |
|----------|---------|
| Reset systemu | Co godzinę parzystą (automatyczne przywrócenie stanu początkowego) |
| Blokada logowania | 3 nieudane próby → blokada na 5 minut |
| Jednoczesni użytkownicy | Wiele osób może logować się na to samo konto |
| Widoczność danych | Inni użytkownicy widzą dane wprowadzane w czasie rzeczywistym |
| Przechowywanie danych | Dane usuwane cyklicznie przy resetach |

### 2.3 Wymagania techniczne
- **System operacyjny:** Windows
- **Przeglądarki:** Microsoft Edge, Mozilla Firefox, Google Chrome, Opera, Safari
- **Dodatkowe aplikacje:**
  - **NASK Desk** - do edycji plików w systemie (wymaga odinstalowania FileMonitor)
  - **QuickScan** - do skanowania dokumentów i tworzenia odwzorowań cyfrowych
- **Źródło aplikacji:** [Podręcznik użytkownika EZD RP](https://podrecznik.ezdrp.gov.pl/dodatkowe-aplikacje-systemowe/)

---

## 3. Role Użytkowników i Uprawnienia

### 3.1 Konta testowe dostępne w Demo

| Rola | Nazwa użytkownika | Login | Hasło |
|------|-------------------|-------|-------|
| **Pracownik kancelarii** | Zofia Podkarpacka | `zofiap` | `EzdTest1234!` |
| **Pracownik kancelarii** | Zofia Śląska | `zofias` | `EzdTest1234!` |
| **Pracownik merytoryczny** | Roman Mazowiecki | `romanm` | `EzdTest1234!` |
| **Pracownik merytoryczny** | Aleksandra Dolnośląska | `aleksandrad` | `EzdTest1234!` |
| **Kierownik** | Dorota Wielkopolska | `dorotaw` | `EzdTest1234!` |

### 3.2 Funkcjonalności per rola

#### 3.2.1 Pracownik Kancelarii / Sekretariatu
- Rejestrowanie korespondencji przychodzącej (papierowej i elektronicznej)
- Uzupełnianie metadanych przesyłek wpływających
- Tworzenie odwzorowań cyfrowych (QuickScan)
- Obsługa składów chronologicznych
- Tworzenie zestawień przesyłek wychodzących
- Dodawanie nowych pozycji do bazy kontaktów
- Edycja plików (wymaga NASK Desk)

#### 3.2.2 Pracownik Merytoryczny
- Zakładanie nowych spraw
- Kompletowanie i zarządzanie dokumentacją akt spraw
- Zmiany tytułów spraw, terminów realizacji
- Dodawanie notatek i przerejestrowywanie spraw
- Tworzenie i edycja dokumentów w ramach sprawy
- Przekazywanie dokumentów do akceptacji/podpisu przełożonego
- Udostępnianie dokumentów innym użytkownikom
- Współdzielenie akt
- Obsługa wysyłek korespondencji (listowna, ePUAP*, e-mail*)
- Korzystanie z wyszukiwarki
* _W Demo: tylko symulacja, brak rzeczywistego wysyłania_

#### 3.2.3 Kierownik Komórki Organizacyjnej
- Wszystkie uprawnienia pracownika merytorycznego
- **Rozdzielanie korespondencji** - przypisywanie pism do konkretnych pracowników
- Akceptowanie i podpisywanie pism
- Nadzór nad przepływem dokumentów w organizacji

### 3.3 Ograniczenia kont demo
- ❌ Brak dostępu do ustawień administracyjnych
- ❌ Brak możliwości konfiguracji aplikacji
- ❌ Brak rzeczywistego odbierania/wysyłania przez ePUAP
- ❌ Brak rzeczywistego wysyłania wiadomości e-mail

---

## 4. Architektura i Moduły Systemu

### 4.1 Główne moduły funkcjonalne
1. **Moduł Kancelarii** - obsługa korespondencji przychodzącej/wychodzącej
2. **Moduł Spraw** - zarządzanie aktami spraw, metadanymi, terminami
3. **Moduł Dokumentów** - tworzenie, edycja, wersjonowanie, podpisywanie
4. **Moduł Wyszukiwania** - zaawansowane wyszukiwanie dokumentów i spraw
5. **Moduł Kontaktów** - baza adresatów, instytucje, osoby
6. **Moduł Zadań/Wiadomości** - przepływ zadań, powiadomienia, delegowanie
7. **Moduł Archiwizacji** - zgodność z JRWA, kategoryzacja, retencja

### 4.2 Integracje
- **ePUAP** - elektroniczna Platforma Usług Administracji Publicznej
- **Systemy pocztowe** (SMTP/IMAP)
- **Skanery** (poprzez QuickScan)
- **Edytory dokumentów** (poprzez NASK Desk)

---

## 5. Struktura Organizacyjna w Demo

Demo zawiera **predefiniowaną przykładową strukturę organizacyjną**, identyczną dla wszystkich użytkowników, umożliwiającą pracę na trzech stanowiskach:
- Stanowisko pracownika kancelarii/sekretariatu
- Stanowisko pracownika merytorycznego
- Stanowisko kierownika komórki organizacyjnej

---

## 6. Materiały i Zasoby

### 6.1 Dokumenty do pobrania
| Nazwa pliku | Opis | Rozmiar |
|-------------|------|---------|
| `Opis_konfiguracji_demonstracyjnej_wersji_EZD_RP_18042025.pdf` | Szczegółowy opis konfiguracji demo | 0.09 MB |
| `Polityka_prywatności_informacja_cookies_dla_demonstracyjnej_wersji_EZD_RP_18042025.pdf` | Polityka prywatności i cookies | 0.07 MB |
| `Regulamin_korzystania_z_demonstracyjnej_wersji_EZD_RP_18042025.pdf` | Regulamin korzystania z demo | 0.09 MB |

### 6.2 Materiały szkoleniowe
- **Filmy instruktażowe:** [YouTube Playlist](https://www.youtube.com/playlist?list=PLX4bu54E7hyOvgSAN0Ya2FoeipvEniXqf)
- **Prezentacja możliwości systemu:** [YouTube](https://youtu.be/wK99ujUJNGI)
- **Podręcznik użytkownika:** https://podrecznik.ezdrp.gov.pl/
- **Piaskownica API:** https://www.gov.pl/web/ezd-rp/piaskownica-api

### 6.3 Linki oficjalne
- Strona główna EZD RP: https://www.gov.pl/web/ezd-rp
- Wersja demonstracyjna: https://www.gov.pl/web/ezd-rp/wersja-demonstracyjna
- Aktualności: https://www.gov.pl/web/ezd-rp/aktualnosci
- Wdrożenia i wsparcie: https://www.gov.pl/web/ezd-rp/wdrozenia
- Licencja: https://www.gov.pl/web/ezd-rp/licencja-ezd-rp
- Wymagania sprzętowe: https://www.gov.pl/web/ezd-rp/wymagania-i-rekomendacje

---

## 7. Bezpieczeństwo i Zgodność

### 7.1 Aspekty bezpieczeństwa
- System hostowany w chmurze rządowej (bezpieczna infrastruktura)
- Uwierzytelnianie login/hasło (w produkcji: Profil Zaufany, eIDAS)
- Separacja ról i uprawnień (RBAC)
- Logowanie zdarzeń (audit trail)
- Szyfrowanie transmisji (HTTPS/TLS)

### 7.2 Zgodność prawna
- Zgodność z Kodeksem postępowania administracyjnego
- Zgodność z ustawą o Narodowym Cyfrowym Interfejsie (NKI)
- Obsługa **JRWA** (Jednolity Rzeczowy Wykaz Akt)
- Zgodność z RODO (Polityka prywatności dostępna w materiałach)
- Standardy dostępności cyfrowej (WCAG)

---

## 8. Scenariusze Testowe (dla Demo)

### 8.1 Scenariusz: Pełny cykl korespondencji przychodzącej
1. Zaloguj jako **Pracownik kancelarii** (zofiap)
2. Zarejestruj nową przesyłkę przychodzącą (papierową)
3. Uzupełnij metadane (nadawca, data, podpis, słowa kluczowe)
4. Zeskanuj załączniki (QuickScan)
5. Przekaż do rozdzielenia (kierownik)

### 8.2 Scenariusz: Tworzenie i prowadzenie sprawy
1. Zaloguj jako **Pracownik merytoryczny** (romanm)
2. Załóż nową sprawę na podstawie przesyłki
3. Uzupełnij metadane sprawy (tytuł, termin, kategoria JRWA)
4. Utwórz dokument w sprawie (np. pismo odpisowe)
5. Przekaż do akceptacji/kontroli kierownika

### 8.3 Scenariusz: Proces decyzyjny kierownika
1. Zaloguj jako **Kierownik** (dorotaw)
2. Odbierz korespondencję do rozdzielenia
3. Przypisz pisma do odpowiednich pracowników merytorycznych
4. Przejrzyj przygotowane projekty pism
5. Zaakceptuj/podpisz dokumenty końcowe

### 8.4 Scenariusz: Współpraca i zastępstwo
1. Dwoje użytkowników loguje się na to samo konto (np. zofiap)
2. Jeden rejestruje korespondencję, drugi uzupełnia metadane
3. Test pracy w zastępstwie - przejęcie zadań innego użytkownika

---

## 9. Znane Ograniczenia Wersji Demo

| Ograniczenie | Opis |
|--------------|------|
| Reset co 2h | W każdej godzinie parzystej system wraca do stanu początkowego |
| Brak ePUAP/e-mail | Tylko symulacja wysyłki, brak realnej integracji |
| Brak panelu admin | Nie można konfigurować struktury, uprawnień, słowników |
| Dane widoczne dla wszystkich | Brak izolacji danych między użytkownikami testowymi |
| Brak trwałości | Wszystkie zmiany znikają po resecie |

---

## 10. Plan Wdrożenia (Produkcja)

### 10.1 Etapy wdrożenia
1. **Analiza wymagań** - audyt procesów kancelaryjnych w instytucji
2. **Przygotowanie środowiska** - instalacja serwerowa lub SaaS
3. **Konfiguracja** - struktura organizacyjna, uprawnienia, słowniki, JRWA
4. **Migracja danych** - import archiwum, kontaktów, szablonów
5. **Szkolenia** - administratorzy, pracownicy kancelarii, merytorycy, kierownicy
6. **Uruchomienie produkcyjne** (Go-live)
7. **Wsparcie post-wdrożeniowe** - helpdesk, aktualizacje, optymalizacja

### 10.2 Modele wdrożenia
- **SaaS EZD RP** - usługa chmurowa (zarządzana przez operatora)
- **Wdrożenie on-premise** - na infrastrukturze własnej instytucji
- **Model hybrydowy**

### 10.3 Wsparcie wdrożeniowe
- Partnerzy EZD RP: https://www.gov.pl/web/ezd-rp/partnerzy-ezd-rp
- Szkolenia: https://www.gov.pl/web/ezd-rp/szkolenia
- Dokumenty wdrożeniowe: https://www.gov.pl/web/ezd-rp/dokumenty-wdrozeniowe
- FAQ: https://www.gov.pl/web/ezd-rp/wdrozenia-faq

---

## 11. Kontakt i Wsparcie

- **Strona kontaktowa:** https://www.gov.pl/web/ezd-rp/kontakt
- **Wsparcie wdrożeniowe:** https://www.gov.pl/web/ezd-rp/wsparcie-wdrozeniowe
- **Portal EZD RP:** https://ezdrp.gov.pl/
- **Podręcznik użytkownika:** https://podrecznik.ezdrp.gov.pl/

---

## 12. Historia Wersji Dokumentacji

| Wersja | Data | Autor | Zmiany |
|--------|------|-------|--------|
| 1.0 | 2026-09-07 | - | Wersja początkowa oparta na oficjalnych źródach gov.pl |

---

## 13. Licencja i Prawa Autorskie

Treści tekstowe udostępniane na licencji **Creative Commons: Uznanie autorstwa - Na tych samych warunkach 4.0 (CC BY-SA 4.0)**.
Materiały audiowizualne na licencji **CC BY-NC-ND 4.0**.

Źródło: Oficjalny portal https://www.gov.pl/web/ezd-rp

---

*Dokumentacja przygotowana na podstawie informacji publicznie dostępnych na portalu Gov.pl (stan na 07.09.2026). Dla najnowszych informacji zawsze sprawdzaj oficjalne źródła.*