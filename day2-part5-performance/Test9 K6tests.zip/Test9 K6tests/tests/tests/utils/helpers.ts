import { Page, Locator, expect } from '@playwright/test';

export const CLICK_DELAY_MS = 500;

export async function waitBeforeClick(locator: Locator, delayMs = CLICK_DELAY_MS) {
  await locator.waitFor({ state: 'visible' });
  await new Promise(resolve => setTimeout(resolve, delayMs));
  await locator.click();
}

export async function waitForNetworkIdle(page: Page, timeout = 5000) {
  await page.waitForLoadState('networkidle', { timeout });
}

export async function takeScreenshot(page: Page, name: string) {
  await page.screenshot({ path: `test-results/screenshots/${name}-${Date.now()}.png`, fullPage: true });
}

export function generateRandomString(prefix = 'test', length = 8): string {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let result = prefix + '-';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

export function getTodayDate(): string {
  const today = new Date();
  return today.toISOString().split('T')[0];
}

export function getFutureDate(days: number): string {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return date.toISOString().split('T')[0];
}

export async function fillDateInput(page: Page, selector: string, date: string) {
  const input = page.locator(selector);
  await input.fill(date);
  await input.press('Tab');
}

export async function selectFromDropdown(page: Page, triggerSelector: string, optionText: string) {
  await page.locator(triggerSelector).click();
  await page.locator(`option:has-text("${optionText}"), li:has-text("${optionText}"), [role="option"]:has-text("${optionText}")`).first().click();
}

export async function expectToastMessage(page: Page, message: string, type: 'success' | 'error' | 'info' = 'success') {
  const selector = type === 'success' 
    ? '.toast-success, .alert-success, .notification-success'
    : type === 'error'
    ? '.toast-error, .alert-danger, .notification-error'
    : '.toast-info, .alert-info, .notification-info';
  
  const toast = page.locator(selector).first();
  await expect(toast).toBeVisible({ timeout: 5000 });
  await expect(toast).toContainText(message);
}

export async function handleConfirmDialog(page: Page, accept = true) {
  page.on('dialog', async dialog => {
    if (accept) {
      await dialog.accept();
    } else {
      await dialog.dismiss();
    }
  });
}

export function createTestData() {
  const timestamp = Date.now();
  const random = Math.random().toString(36).substring(2, 8);
  return {
    tytul: `Test Sprawa ${timestamp}-${random}`,
    numer: `TEST/${timestamp}/${random}`,
    tresc: `Treść testowa wygenerowana automatycznie ${new Date().toISOString()}`,
    opis: `Opis testowy ${timestamp}`,
  };
}