import { Page, Locator, expect } from '@playwright/test';
import { waitBeforeClick } from '../utils/helpers';

export class LoginPage {
  readonly page: Page;
  readonly loginInput: Locator;
  readonly passwordInput: Locator;
  readonly submitButton: Locator;
  readonly errorMessage: Locator;
  readonly rememberMeCheckbox: Locator;

  constructor(page: Page) {
    this.page = page;
    // More flexible selectors for various possible attribute names
    this.loginInput = page.locator('input[name*="login" i], input[name*="user" i], input[name*="email" i], input[id*="login" i], input[id*="user" i], input[type="text"], input[type="email"]').first();
    this.passwordInput = page.locator('input[name*="pass" i], input[id*="pass" i], input[type="password"]').first();
    this.submitButton = page.locator('button[type="submit"], input[type="submit"], button:has-text("Zaloguj"), button:has-text("Zaloguj się"), button:has-text("Log in"), button:has-text("Sign in")').first();
    this.errorMessage = page.locator('.alert-danger, .error-message, [role="alert"], .validation-error, .text-danger, .error').first();
    this.rememberMeCheckbox = page.locator('input[name*="remember" i], input[id*="remember" i]').first();
  }

  async goto() {
    await this.page.goto('/login');
    await this.page.waitForLoadState('domcontentloaded');
    // Handle potential cookie banner
    await this.handleCookieBanner();
    // Wait for login form to be visible
    await this.loginInput.waitFor({ state: 'visible', timeout: 30000 });
  }

  private async handleCookieBanner() {
    try {
      const acceptButton = this.page.locator('button:has-text("Akceptuj"), button:has-text("Zgadzam"), button:has-text("Accept"), button:has-text("OK"), button[id*="cookie"], button[class*="cookie"]').first();
      if (await acceptButton.isVisible({ timeout: 3000 })) {
        await waitBeforeClick(acceptButton);
      }
    } catch {
      // Cookie banner not present or already handled
    }
  }

  async login(login: string, password: string) {
    await this.loginInput.waitFor({ state: 'visible', timeout: 15000 });
    await this.loginInput.fill(login);
    await this.passwordInput.waitFor({ state: 'visible', timeout: 5000 });
    await this.passwordInput.fill(password);
    await this.submitButton.waitFor({ state: 'visible', timeout: 5000 });
    await waitBeforeClick(this.submitButton);
    await this.page.waitForLoadState('networkidle', { timeout: 30000 });
  }

  async expectLoginError(message?: string) {
    await expect(this.errorMessage).toBeVisible();
    if (message) {
      await expect(this.errorMessage).toContainText(message);
    }
  }

  async expectLoggedIn() {
    await expect(this.page).not.toHaveURL(/\/login/);
  }
}