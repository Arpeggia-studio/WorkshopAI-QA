import { Page, Locator, expect } from '@playwright/test';
import { waitBeforeClick } from '../utils/helpers';

export class DashboardPage {
  readonly page: Page;
  readonly userMenu: Locator;
  readonly logoutButton: Locator;
  readonly navigationMenu: Locator;
  readonly breadcrumbs: Locator;

  constructor(page: Page) {
    this.page = page;
    this.userMenu = page.locator('.user-menu, [data-testid="user-menu"], .dropdown-toggle:has-text("Zofia"), .dropdown-toggle:has-text("Roman"), .dropdown-toggle:has-text("Dorota"), .dropdown-toggle:has-text("Aleksandra")').first();
    this.logoutButton = page.locator('a:has-text("Wyloguj"), button:has-text("Wyloguj"), [href*="logout"]').first();
    this.navigationMenu = page.locator('nav, .sidebar, .navigation, [role="navigation"]').first();
    this.breadcrumbs = page.locator('.breadcrumb, .breadcrumbs, nav[aria-label="Breadcrumb"]').first();
  }

  async expectLoaded() {
    await expect(this.page).not.toHaveURL(/\/login/);
    await this.page.waitForLoadState('networkidle');
  }

  async getUserName(): Promise<string | null> {
    const text = await this.userMenu.textContent();
    return text?.trim() || null;
  }

  async logout() {
    await waitBeforeClick(this.userMenu);
    await waitBeforeClick(this.logoutButton);
    await this.page.waitForURL(/\/login/);
  }

  async navigateTo(menuText: string) {
    const link = this.navigationMenu.locator(`a:has-text("${menuText}"), button:has-text("${menuText}")`).first();
    await waitBeforeClick(link);
    await this.page.waitForLoadState('networkidle');
  }

  async expectNavigationVisible() {
    await expect(this.navigationMenu).toBeVisible();
  }
}