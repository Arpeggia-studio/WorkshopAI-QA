import { Page, Locator, expect } from '@playwright/test';
import { waitBeforeClick } from '../utils/helpers';

export class KorespondencjaPrzychodzacaPage {
  readonly page: Page;
  readonly nowaPrzesylkaButton: Locator;
  readonly listaPrzesylek: Locator;
  readonly filtry: Locator;
  readonly wyszukiwarka: Locator;
  readonly tabelaPrzesylek: Locator;

  constructor(page: Page) {
    this.page = page;
    this.nowaPrzesylkaButton = page.locator('button:has-text("Nowa przesyłka"), a:has-text("Nowa przesyłka"), [data-testid="nowa-przesylka"]').first();
    this.listaPrzesylek = page.locator('.przesylki-list, table.przesylki, [data-testid="lista-przesylek"]').first();
    this.filtry = page.locator('.filters, .filtry, [data-testid="filtry"]').first();
    this.wyszukiwarka = page.locator('input[type="search"], input[placeholder*="szukaj" i], input[placeholder*="wyszukaj" i]').first();
    this.tabelaPrzesylek = page.locator('table tbody, .table-body, [data-testid="tabela-przesylek"]').first();
  }

  async goto() {
    await this.page.goto('/korespondencja/przychodzaca');
    await this.page.waitForLoadState('networkidle');
  }

  async expectLoaded() {
    await expect(this.page).toHaveURL(/\/korespondencja\/przychodzaca/);
    await expect(this.nowaPrzesylkaButton).toBeVisible({ timeout: 10000 });
  }

  async kliknijNowaPrzesylka() {
    await waitBeforeClick(this.nowaPrzesylkaButton);
    await this.page.waitForLoadState('networkidle');
  }

  async wyszukajPrzesylke(tekst: string) {
    await this.wyszukiwarka.fill(tekst);
    await this.page.keyboard.press('Enter');
    await this.page.waitForLoadState('networkidle');
  }

  async otworzPrzesylke(numerLubTytul: string) {
    const wiersz = this.tabelaPrzesylek.locator(`tr:has-text("${numerLubTytul}"), td:has-text("${numerLubTytul}")`).first();
    await waitBeforeClick(wiersz);
    await this.page.waitForLoadState('networkidle');
  }

  async sprawdzCzyPrzesylkaIstnieje(numerLubTytul: string): Promise<boolean> {
    const wiersz = this.tabelaPrzesylek.locator(`tr:has-text("${numerLubTytul}"), td:has-text("${numerLubTytul}")`).first();
    return await wiersz.isVisible({ timeout: 5000 });
  }
}