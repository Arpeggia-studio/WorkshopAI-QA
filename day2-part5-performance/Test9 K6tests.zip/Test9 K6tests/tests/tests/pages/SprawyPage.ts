import { Page, Locator, expect } from '@playwright/test';
import { waitBeforeClick } from '../utils/helpers';

export class SprawyPage {
  readonly page: Page;
  readonly nowaSprawaButton: Locator;
  readonly listaSpraw: Locator;
  readonly wyszukiwarka: Locator;
  readonly filtry: Locator;
  readonly tabelaSpraw: Locator;

  constructor(page: Page) {
    this.page = page;
    this.nowaSprawaButton = page.locator('button:has-text("Nowa sprawa"), a:has-text("Nowa sprawa"), [data-testid="nowa-sprawa"]').first();
    this.listaSpraw = page.locator('.sprawy-list, table.sprawy, [data-testid="lista-spraw"]').first();
    this.wyszukiwarka = page.locator('input[type="search"], input[placeholder*="szukaj" i], input[placeholder*="wyszukaj" i]').first();
    this.filtry = page.locator('.filters, .filtry, [data-testid="filtry"]').first();
    this.tabelaSpraw = page.locator('table tbody, .table-body, [data-testid="tabela-spraw"]').first();
  }

  async goto() {
    await this.page.goto('/sprawy');
    await this.page.waitForLoadState('networkidle');
  }

  async expectLoaded() {
    await expect(this.page).toHaveURL(/\/sprawy/);
    await expect(this.nowaSprawaButton).toBeVisible({ timeout: 10000 });
  }

  async kliknijNowaSprawa() {
    await waitBeforeClick(this.nowaSprawaButton);
    await this.page.waitForLoadState('networkidle');
  }

  async wyszukajSprawe(tekst: string) {
    await this.wyszukiwarka.fill(tekst);
    await this.page.keyboard.press('Enter');
    await this.page.waitForLoadState('networkidle');
  }

  async otworzSprawe(numerLubTytul: string) {
    const wiersz = this.tabelaSpraw.locator(`tr:has-text("${numerLubTytul}"), td:has-text("${numerLubTytul}")`).first();
    await waitBeforeClick(wiersz);
    await this.page.waitForLoadState('networkidle');
  }

  async sprawdzCzySprawaIstnieje(numerLubTytul: string): Promise<boolean> {
    const wiersz = this.tabelaSpraw.locator(`tr:has-text("${numerLubTytul}"), td:has-text("${numerLubTytul}")`).first();
    return await wiersz.isVisible({ timeout: 5000 });
  }
}