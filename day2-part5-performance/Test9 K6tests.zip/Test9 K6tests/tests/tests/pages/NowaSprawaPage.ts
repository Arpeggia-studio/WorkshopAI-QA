import { Page, Locator, expect } from '@playwright/test';
import { waitBeforeClick } from '../utils/helpers';

export class NowaSprawaPage {
  readonly page: Page;
  readonly formularz: Locator;
  readonly tytulInput: Locator;
  readonly terminInput: Locator;
  readonly kategoriaSelect: Locator;
  readonly jrwaSelect: Locator;
  readonly opisTextarea: Locator;
  readonly zapiszButton: Locator;
  readonly zapiszIZamknijButton: Locator;
  readonly anulujButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.formularz = page.locator('form, .formularz, [data-testid="formularz-sprawy"]').first();
    this.tytulInput = page.locator('input[name*="tytul"], input[id*="tytul"], [data-testid="tytul-sprawy"]').first();
    this.terminInput = page.locator('input[name*="termin"], input[id*="termin"], [data-testid="termin-realizacji"]').first();
    this.kategoriaSelect = page.locator('select[name*="kategoria"], select[id*="kategoria"], [data-testid="kategoria-sprawy"]').first();
    this.jrwaSelect = page.locator('select[name*="jrwa"], select[id*="jrwa"], [data-testid="jrwa"]').first();
    this.opisTextarea = page.locator('textarea[name*="opis"], textarea[id*="opis"], [data-testid="opis-sprawy"]').first();
    this.zapiszButton = page.locator('button:has-text("Zapisz"), button[type="submit"]').first();
    this.zapiszIZamknijButton = page.locator('button:has-text("Zapisz i zamknij")').first();
    this.anulujButton = page.locator('button:has-text("Anuluj"), a:has-text("Anuluj")').first();
  }

  async expectLoaded() {
    await expect(this.formularz).toBeVisible({ timeout: 10000 });
  }

  async ustawTytul(tytul: string) {
    await this.tytulInput.fill(tytul);
  }

  async ustawTermin(termin: string) {
    await this.terminInput.fill(termin);
  }

  async wybierzKategorie(kategoria: string) {
    await waitBeforeClick(this.kategoriaSelect);
    await waitBeforeClick(this.page.locator(`option:has-text("${kategoria}"), li:has-text("${kategoria}")`).first());
  }

  async wybierzJRWA(jrwa: string) {
    await waitBeforeClick(this.jrwaSelect);
    await waitBeforeClick(this.page.locator(`option:has-text("${jrwa}"), li:has-text("${jrwa}")`).first());
  }

  async ustawOpis(opis: string) {
    await this.opisTextarea.fill(opis);
  }

  async zapisz() {
    await waitBeforeClick(this.zapiszButton);
    await this.page.waitForLoadState('networkidle');
  }

  async zapiszIZamknij() {
    await waitBeforeClick(this.zapiszIZamknijButton);
    await this.page.waitForLoadState('networkidle');
  }

  async anuluj() {
    await waitBeforeClick(this.anulujButton);
    await this.page.waitForLoadState('networkidle');
  }

  async wypelnijFormularz(dane: {
    tytul?: string;
    termin?: string;
    kategoria?: string;
    jrwa?: string;
    opis?: string;
  }) {
    if (dane.tytul) await this.ustawTytul(dane.tytul);
    if (dane.termin) await this.ustawTermin(dane.termin);
    if (dane.kategoria) await this.wybierzKategorie(dane.kategoria);
    if (dane.jrwa) await this.wybierzJRWA(dane.jrwa);
    if (dane.opis) await this.ustawOpis(dane.opis);
  }
}