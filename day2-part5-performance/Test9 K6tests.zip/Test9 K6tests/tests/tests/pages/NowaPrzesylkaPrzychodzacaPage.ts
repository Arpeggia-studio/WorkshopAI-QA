import { Page, Locator, expect } from '@playwright/test';
import { waitBeforeClick } from '../utils/helpers';

export class NowaPrzesylkaPrzychodzacaPage {
  readonly page: Page;
  readonly formularz: Locator;
  readonly nadawcaSelect: Locator;
  readonly typPrzesylkiSelect: Locator;
  readonly dataWplywuInput: Locator;
  readonly dataDokumentuInput: Locator;
  readonly numerDokumentuInput: Locator;
  readonly sygnaturaInput: Locator;
  readonly tytulInput: Locator;
  readonly trescTextarea: Locator;
  readonly slapstwoInput: Locator;
  readonly zalacznikiInput: Locator;
  readonly zapiszButton: Locator;
  readonly zapiszIZamknijButton: Locator;
  readonly anulujButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.formularz = page.locator('form, .formularz, [data-testid="formularz-przesylki"]').first();
    this.nadawcaSelect = page.locator('select[name*="nadawca"], select[id*="nadawca"], [data-testid="nadawca-select"]').first();
    this.typPrzesylkiSelect = page.locator('select[name*="typ"], select[id*="typ"], [data-testid="typ-przesylki-select"]').first();
    this.dataWplywuInput = page.locator('input[name*="dataWplywu"], input[id*="dataWplywu"], [data-testid="data-wplywu"]').first();
    this.dataDokumentuInput = page.locator('input[name*="dataDokumentu"], input[id*="dataDokumentu"], [data-testid="data-dokumentu"]').first();
    this.numerDokumentuInput = page.locator('input[name*="numerDokumentu"], input[id*="numerDokumentu"], [data-testid="numer-dokumentu"]').first();
    this.sygnaturaInput = page.locator('input[name*="sygnatura"], input[id*="sygnatura"], [data-testid="sygnatura"]').first();
    this.tytulInput = page.locator('input[name*="tytul"], input[id*="tytul"], [data-testid="tytul"]').first();
    this.trescTextarea = page.locator('textarea[name*="tresc"], textarea[id*="tresc"], [data-testid="tresc"]').first();
    this.slapstwoInput = page.locator('input[name*="slapstwo"], input[id*="slapstwo"], [data-testid="slapstwo"]').first();
    this.zalacznikiInput = page.locator('input[type="file"], [data-testid="zalaczniki"]').first();
    this.zapiszButton = page.locator('button:has-text("Zapisz"), button[type="submit"]').first();
    this.zapiszIZamknijButton = page.locator('button:has-text("Zapisz i zamknij"), button:has-text("Zapisz i zamknij")').first();
    this.anulujButton = page.locator('button:has-text("Anuluj"), a:has-text("Anuluj")').first();
  }

  async expectLoaded() {
    await expect(this.formularz).toBeVisible({ timeout: 10000 });
  }

  async wybierzNadawce(nazwa: string) {
    await waitBeforeClick(this.nadawcaSelect);
    await waitBeforeClick(this.page.locator(`option:has-text("${nazwa}"), li:has-text("${nazwa}")`).first());
  }

  async wybierzTypPrzesylki(typ: string) {
    await waitBeforeClick(this.typPrzesylkiSelect);
    await waitBeforeClick(this.page.locator(`option:has-text("${typ}"), li:has-text("${typ}")`).first());
  }

  async ustawDateWplywu(data: string) {
    await this.dataWplywuInput.fill(data);
  }

  async ustawDateDokumentu(data: string) {
    await this.dataDokumentuInput.fill(data);
  }

  async ustawNumerDokumentu(numer: string) {
    await this.numerDokumentuInput.fill(numer);
  }

  async ustawSygnature(sygnatura: string) {
    await this.sygnaturaInput.fill(sygnatura);
  }

  async ustawTytul(tytul: string) {
    await this.tytulInput.fill(tytul);
  }

  async ustawTresc(tresc: string) {
    await this.trescTextarea.fill(tresc);
  }

  async ustawSlapstwo(lp: string) {
    await this.slapstwoInput.fill(lp);
  }

  async zalaczPlik(sciezka: string) {
    await this.zalacznikiInput.setInputFiles(sciezka);
  }

  async zapisz() {
    await waitBeforeClick(this.zapiszButton);
    await this.page.waitForLoadState('networkidle');
  }

  async zapiszIZamknij() {
    await waitBeforeClick(this.zapiszIZamknijButton);
    await this.page.waitForLoadState('networkidle');
  }

  async anuluj() {
    await waitBeforeClick(this.anulujButton);
    await this.page.waitForLoadState('networkidle');
  }

  async wypelnijFormularz(dane: {
    nadawca?: string;
    typPrzesylki?: string;
    dataWplywu?: string;
    dataDokumentu?: string;
    numerDokumentu?: string;
    sygnatura?: string;
    tytul?: string;
    tresc?: string;
    slapstwo?: string;
  }) {
    if (dane.nadawca) await this.wybierzNadawce(dane.nadawca);
    if (dane.typPrzesylki) await this.wybierzTypPrzesylki(dane.typPrzesylki);
    if (dane.dataWplywu) await this.ustawDateWplywu(dane.dataWplywu);
    if (dane.dataDokumentu) await this.ustawDateDokumentu(dane.dataDokumentu);
    if (dane.numerDokumentu) await this.ustawNumerDokumentu(dane.numerDokumentu);
    if (dane.sygnatura) await this.ustawSygnature(dane.sygnatura);
    if (dane.tytul) await this.ustawTytul(dane.tytul);
    if (dane.tresc) await this.ustawTresc(dane.tresc);
    if (dane.slapstwo) await this.ustawSlapstwo(dane.slapstwo);
  }
}