import { test, expect } from '@playwright/test';
import { LoginPage } from './pages/LoginPage';
import { DashboardPage } from './pages/DashboardPage';
import { KorespondencjaPrzychodzacaPage } from './pages/KorespondencjaPrzychodzacaPage';
import { NowaPrzesylkaPrzychodzacaPage } from './pages/NowaPrzesylkaPrzychodzacaPage';
import { TEST_USERS } from './test-data/users';
import { createTestData, getTodayDate } from './utils/helpers';

test.describe('Sesja i współpraca wielu użytkowników', () => {
  test('dwóch użytkowników na tym samym koncie widzi zmiany drugiego', async ({ browser }) => {
    const context1 = await browser.newContext();
    const context2 = await browser.newContext();
    
    const page1 = await context1.newPage();
    const page2 = await context2.newPage();

    const loginPage1 = new LoginPage(page1);
    await loginPage1.goto();
    await loginPage1.login(TEST_USERS.kancelaria.zofiaPodkarpacka.login, TEST_USERS.kancelaria.zofiaPodkarpacka.password);
    await loginPage1.expectLoggedIn();

    const loginPage2 = new LoginPage(page2);
    await loginPage2.goto();
    await loginPage2.login(TEST_USERS.kancelaria.zofiaPodkarpacka.login, TEST_USERS.kancelaria.zofiaPodkarpacka.password);
    await loginPage2.expectLoggedIn();

    const listaPage1 = new KorespondencjaPrzychodzacaPage(page1);
    await listaPage1.goto();
    await listaPage1.expectLoaded();

    const listaPage2 = new KorespondencjaPrzychodzacaPage(page2);
    await listaPage2.goto();
    await listaPage2.expectLoaded();

    await listaPage1.kliknijNowaPrzesylka();
    const formPage1 = new NowaPrzesylkaPrzychodzacaPage(page1);
    await formPage1.expectLoaded();

    const testData = createTestData();
    await formPage1.wypelnijFormularz({
      tytul: testData.tytul,
      numerDokumentu: testData.numer,
      dataWplywu: getTodayDate(),
      dataDokumentu: getTodayDate(),
      tresc: testData.tresc,
    });
    await formPage1.zapiszIZamknij();

    await page2.waitForTimeout(2000);
    await page2.reload();
    await listaPage2.wyszukajPrzesylke(testData.numer);
    
    const widoczne = await listaPage2.sprawdzCzyPrzesylkaIstnieje(testData.numer);
    expect(widoczne).toBeTruthy();

    await context1.close();
    await context2.close();
  });

  test('użytkownik może pracować w zastępstwie (logowanie na inne konto tej samej roli)', async ({ browser }) => {
    const context1 = await browser.newContext();
    const context2 = await browser.newContext();
    
    const page1 = await context1.newPage();
    const page2 = await context2.newPage();

    const loginPage1 = new LoginPage(page1);
    await loginPage1.goto();
    await loginPage1.login(TEST_USERS.kancelaria.zofiaPodkarpacka.login, TEST_USERS.kancelaria.zofiaPodkarpacka.password);
    await loginPage1.expectLoggedIn();

    const loginPage2 = new LoginPage(page2);
    await loginPage2.goto();
    await loginPage2.login(TEST_USERS.kancelaria.zofiaSlaska.login, TEST_USERS.kancelaria.zofiaSlaska.password);
    await loginPage2.expectLoggedIn();

    const dashboard1 = new DashboardPage(page1);
    const dashboard2 = new DashboardPage(page2);
    
    const user1 = await dashboard1.getUserName();
    const user2 = await dashboard2.getUserName();
    
    expect(user1).toContain('Zofia');
    expect(user2).toContain('Zofia');
    expect(user1).not.toBe(user2);

    await context1.close();
    await context2.close();
  });

  test('reset systemu co godzinę parzystą - symulacja', async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login(TEST_USERS.kancelaria.zofiaPodkarpacka.login, TEST_USERS.kancelaria.zofiaPodkarpacka.password);
    await loginPage.expectLoggedIn();

    const dashboardPage = new DashboardPage(page);
    await dashboardPage.expectLoaded();
    
    const userName = await dashboardPage.getUserName();
    expect(userName).toBeTruthy();
    
    await page.reload();
    await page.waitForLoadState('networkidle');
    
    await expect(page).not.toHaveURL(/\/login/);
  });
});

test.describe('Blokada logowania po 3 nieudanych próbach', () => {
  test('po 3 błędnych logowaniach konto jest blokowane na 5 minut', async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();

    for (let i = 0; i < 3; i++) {
      await loginPage.login('zofiap', 'BledneHaslo123!');
      await loginPage.expectLoginError();
      await page.reload();
      await loginPage.goto();
    }

    await loginPage.login('zofiap', 'BledneHaslo123!');
    await loginPage.expectLoginError(/zablokow|blocked|przekroczon|wait|poczekaj/i);
  });
});