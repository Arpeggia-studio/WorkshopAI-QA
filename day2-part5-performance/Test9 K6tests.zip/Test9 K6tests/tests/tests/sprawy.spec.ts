import { testAsMerytoryczny as test, expect } from './fixtures/auth';
import { SprawyPage } from './pages/SprawyPage';
import { NowaSprawaPage } from './pages/NowaSprawaPage';
import { createTestData, getTodayDate, getFutureDate } from './utils/helpers';

test.describe('Sprawy - Pracownik Merytoryczny', () => {
  test('powinno wyświetlić listę spraw', async ({ loggedInPage }) => {
    const page = new SprawyPage(loggedInPage);
    await page.goto();
    await page.expectLoaded();
    await expect(page.nowaSprawaButton).toBeVisible();
  });

  test('powinno umożliwić założenie nowej sprawy', async ({ loggedInPage }) => {
    const listaPage = new SprawyPage(loggedInPage);
    await listaPage.goto();
    await listaPage.expectLoaded();
    
    await listaPage.kliknijNowaSprawa();
    
    const formPage = new NowaSprawaPage(loggedInPage);
    await formPage.expectLoaded();
    
    const testData = createTestData();
    await formPage.wypelnijFormularz({
      tytul: testData.tytul,
      termin: getFutureDate(14),
      opis: testData.opis,
    });
    
    await formPage.zapiszIZamknij();
    
    await expect(loggedInPage).toHaveURL(/\/sprawy/);
  });

  test('powinno wyszukiwać sprawy', async ({ loggedInPage }) => {
    const page = new SprawyPage(loggedInPage);
    await page.goto();
    await page.expectLoaded();
    
    await page.wyszukajSprawe('TEST');
    await expect(page.tabelaSpraw).toBeVisible();
  });
});

test.describe('Sprawy - Walidacja formularza', () => {
  test('powinno wymagać tytułu sprawy', async ({ loggedInPage }) => {
    const listaPage = new SprawyPage(loggedInPage);
    await listaPage.goto();
    await listaPage.kliknijNowaSprawa();
    
    const formPage = new NowaSprawaPage(loggedInPage);
    await formPage.expectLoaded();
    
    await formPage.zapisz();
    
    await expect(formPage.tytulInput).toHaveAttribute('required');
  });

  test('powinno wymagać terminu realizacji', async ({ loggedInPage }) => {
    const listaPage = new SprawyPage(loggedInPage);
    await listaPage.goto();
    await listaPage.kliknijNowaSprawa();
    
    const formPage = new NowaSprawaPage(loggedInPage);
    await formPage.expectLoaded();
    
    await formPage.ustawTytul('Test bez terminu');
    await formPage.zapisz();
    
    await expect(formPage.terminInput).toHaveAttribute('required');
  });
});