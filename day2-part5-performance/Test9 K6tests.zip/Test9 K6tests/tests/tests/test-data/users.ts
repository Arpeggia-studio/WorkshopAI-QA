export const TEST_USERS = {
  kancelaria: {
    zofiaPodkarpacka: {
      login: 'zofiap',
      password: 'EzdTest1234!',
      fullName: 'Zofia Podkarpacka',
      role: 'pracownik_kancelarii' as const,
    },
    zofiaSlaska: {
      login: 'zofias',
      password: 'EzdTest1234!',
      fullName: 'Zofia Śląska',
      role: 'pracownik_kancelarii' as const,
    },
  },
  merytoryczni: {
    romanMazowiecki: {
      login: 'romanm',
      password: 'EzdTest1234!',
      fullName: 'Roman Mazowiecki',
      role: 'pracownik_merytoryczny' as const,
    },
    aleksandraDolnoslaska: {
      login: 'aleksandrad',
      password: 'EzdTest1234!',
      fullName: 'Aleksandra Dolnośląska',
      role: 'pracownik_merytoryczny' as const,
    },
  },
  kierownicy: {
    dorotaWielkopolska: {
      login: 'dorotaw',
      password: 'EzdTest1234!',
      fullName: 'Dorota Wielkopolska',
      role: 'kierownik' as const,
    },
  },
} as const;

export type UserRole = 'pracownik_kancelarii' | 'pracownik_merytoryczny' | 'kierownik';
export type TestUser = typeof TEST_USERS.kancelaria.zofiaPodkarpacka;

export function getAllUsers(): TestUser[] {
  return [
    ...Object.values(TEST_USERS.kancelaria),
    ...Object.values(TEST_USERS.merytoryczni),
    ...Object.values(TEST_USERS.kierownicy),
  ];
}

export function getUsersByRole(role: UserRole): TestUser[] {
  switch (role) {
    case 'pracownik_kancelarii':
      return Object.values(TEST_USERS.kancelaria);
    case 'pracownik_merytoryczny':
      return Object.values(TEST_USERS.merytoryczni);
    case 'kierownik':
      return Object.values(TEST_USERS.kierownicy);
  }
}

export const DEMO_CONFIG = {
  baseUrl: 'https://ezdrp-web.demo.ezdrp.gov.pl',
  resetHours: [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22],
  loginBlockDuration: 5 * 60 * 1000,
  maxLoginAttempts: 3,
} as const;

export const TEST_URLS = {
  login: '/login',
  dashboard: '/dashboard',
  korespondencjaPrzychodzaca: '/korespondencja/przychodzaca',
  korespondencjaWychodzaca: '/korespondencja/wychodzaca',
  sprawy: '/sprawy',
  wyszukiwarka: '/wyszukiwarka',
  kontakty: '/kontakty',
  zadania: '/zadania',
  ustawienia: '/ustawienia',
} as const;