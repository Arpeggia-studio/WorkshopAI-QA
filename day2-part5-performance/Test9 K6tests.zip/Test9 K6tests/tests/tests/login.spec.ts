import { test, expect } from './fixtures/auth';
import { TEST_USERS } from './test-data/users';

test.describe('Logowanie do Demo EZD RP', () => {
  test('powinno zalogować pracownika kancelarii', async ({ loginPage }) => {
    const user = TEST_USERS.kancelaria.zofiaPodkarpacka;
    await loginPage.goto();
    await loginPage.login(user.login, user.password);
    await loginPage.expectLoggedIn();
  });

  test('powinno zalogować pracownika merytorycznego', async ({ loginPage }) => {
    const user = TEST_USERS.merytoryczni.romanMazowiecki;
    await loginPage.goto();
    await loginPage.login(user.login, user.password);
    await loginPage.expectLoggedIn();
  });

  test('powinno zalogować kierownika', async ({ loginPage }) => {
    const user = TEST_USERS.kierownicy.dorotaWielkopolska;
    await loginPage.goto();
    await loginPage.login(user.login, user.password);
    await loginPage.expectLoggedIn();
  });

  test('powinno odrzucić błędne hasło', async ({ loginPage }) => {
    await loginPage.goto();
    await loginPage.login('zofiap', 'BledneHaslo123!');
    await loginPage.expectLoginError();
  });

  test('powinno odrzucić nieistniejącego użytkownika', async ({ loginPage }) => {
    await loginPage.goto();
    await loginPage.login('nieistniejacy', 'EzdTest1234!');
    await loginPage.expectLoginError();
  });

  test('powinno zablokować po 3 nieudanych próbach', async ({ loginPage, page }) => {
    await loginPage.goto();
    
    for (let i = 0; i < 3; i++) {
      await loginPage.login('zofiap', 'BledneHaslo123!');
      await loginPage.expectLoginError();
      await page.reload();
      await loginPage.goto();
    }
    
    await loginPage.login('zofiap', 'BledneHaslo123!');
    await loginPage.expectLoginError(/zablokow|blocked|przekroczon/i);
  });
});

test.describe('Wylogowanie', () => {
  test('powinno wylogować użytkownika', async ({ loggedInPage, dashboardPage }) => {
    await dashboardPage.expectLoaded();
    await dashboardPage.logout();
    await expect(loggedInPage).toHaveURL(/\/login/);
  });
});