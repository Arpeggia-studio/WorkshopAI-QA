import { testAsKancelaria as test, expect } from './fixtures/auth';
import { KorespondencjaPrzychodzacaPage } from './pages/KorespondencjaPrzychodzacaPage';
import { NowaPrzesylkaPrzychodzacaPage } from './pages/NowaPrzesylkaPrzychodzacaPage';
import { createTestData, getTodayDate } from './utils/helpers';

test.describe('Korespondencja przychodząca - Pracownik Kancelarii', () => {
  test('powinno wyświetlić listę korespondencji przychodzącej', async ({ loggedInPage }) => {
    const page = new KorespondencjaPrzychodzacaPage(loggedInPage);
    await page.goto();
    await page.expectLoaded();
    await expect(page.nowaPrzesylkaButton).toBeVisible();
  });

  test('powinno umożliwić utworzenie nowej przesyłki przychodzącej', async ({ loggedInPage }) => {
    const listaPage = new KorespondencjaPrzychodzacaPage(loggedInPage);
    await listaPage.goto();
    await listaPage.expectLoaded();
    
    await listaPage.kliknijNowaPrzesylka();
    
    const formPage = new NowaPrzesylkaPrzychodzacaPage(loggedInPage);
    await formPage.expectLoaded();
    
    const testData = createTestData();
    await formPage.wypelnijFormularz({
      tytul: testData.tytul,
      numerDokumentu: testData.numer,
      dataWplywu: getTodayDate(),
      dataDokumentu: getTodayDate(),
      tresc: testData.tresc,
    });
    
    await formPage.zapiszIZamknij();
    
    await expect(loggedInPage).toHaveURL(/\/korespondencja\/przychodzaca/);
  });

  test('powinno wyszukiwać przesyłki po numerze/tytule', async ({ loggedInPage }) => {
    const page = new KorespondencjaPrzychodzacaPage(loggedInPage);
    await page.goto();
    await page.expectLoaded();
    
    await page.wyszukajPrzesylke('TEST');
    await expect(page.tabelaPrzesylek).toBeVisible();
  });
});

test.describe('Korespondencja przychodząca - Walidacja formularza', () => {
  test('powinno wymagać tytułu', async ({ loggedInPage }) => {
    const listaPage = new KorespondencjaPrzychodzacaPage(loggedInPage);
    await listaPage.goto();
    await listaPage.kliknijNowaPrzesylka();
    
    const formPage = new NowaPrzesylkaPrzychodzacaPage(loggedInPage);
    await formPage.expectLoaded();
    
    await formPage.zapisz();
    
    await expect(formPage.tytulInput).toHaveAttribute('required');
  });

  test('powinno wymagać daty wpływu', async ({ loggedInPage }) => {
    const listaPage = new KorespondencjaPrzychodzacaPage(loggedInPage);
    await listaPage.goto();
    await listaPage.kliknijNowaPrzesylka();
    
    const formPage = new NowaPrzesylkaPrzychodzacaPage(loggedInPage);
    await formPage.expectLoaded();
    
    await formPage.ustawTytul('Test bez daty');
    await formPage.zapisz();
    
    await expect(formPage.dataWplywuInput).toHaveAttribute('required');
  });
});