import { test, expect } from '@playwright/test';
import { LoginPage } from './pages/LoginPage';
import { KorespondencjaPrzychodzacaPage } from './pages/KorespondencjaPrzychodzacaPage';
import { NowaPrzesylkaPrzychodzacaPage } from './pages/NowaPrzesylkaPrzychodzacaPage';
import { SprawyPage } from './pages/SprawyPage';
import { NowaSprawaPage } from './pages/NowaSprawaPage';
import { DashboardPage } from './pages/DashboardPage';
import { TEST_USERS } from './test-data/users';
import { createTestData, getTodayDate, getFutureDate } from './utils/helpers';

test.describe('Pełny cykl życia dokumentu (E2E)', () => {
  let numerPrzesylki: string;
  let tytulSprawy: string;

  test('Krok 1: Pracownik kancelarii rejestruje korespondencję przychodzącą', async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login(TEST_USERS.kancelaria.zofiaPodkarpacka.login, TEST_USERS.kancelaria.zofiaPodkarpacka.password);
    await loginPage.expectLoggedIn();

    const listaPage = new KorespondencjaPrzychodzacaPage(page);
    await listaPage.goto();
    await listaPage.expectLoaded();
    await listaPage.kliknijNowaPrzesylka();

    const formPage = new NowaPrzesylkaPrzychodzacaPage(page);
    await formPage.expectLoaded();

    const testData = createTestData();
    numerPrzesylki = testData.numer;
    
    await formPage.wypelnijFormularz({
      nadawca: 'Urząd Miasta',
      typPrzesylki: 'List zwykły',
      dataWplywu: getTodayDate(),
      dataDokumentu: getTodayDate(),
      numerDokumentu: testData.numer,
      sygnatura: 'UM/2024/001',
      tytul: testData.tytul,
      tresc: testData.tresc,
      slapstwo: '2',
    });

    await formPage.zapiszIZamknij();
    await expect(page).toHaveURL(/\/korespondencja\/przychodzaca/);
  });

  test('Krok 2: Kierownik rozdziela korespondencję do pracownika merytorycznego', async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login(TEST_USERS.kierownicy.dorotaWielkopolska.login, TEST_USERS.kierownicy.dorotaWielkopolska.password);
    await loginPage.expectLoggedIn();

    const listaPage = new KorespondencjaPrzychodzacaPage(page);
    await listaPage.goto();
    await listaPage.expectLoaded();
    await listaPage.wyszukajPrzesylke(numerPrzesylki);

    const istnieje = await listaPage.sprawdzCzyPrzesylkaIstnieje(numerPrzesylki);
    if (istnieje) {
      await listaPage.otworzPrzesylke(numerPrzesylki);
      await page.waitForLoadState('networkidle');

      const przyciskRozdzial = page.locator('button:has-text("Rozdział"), button:has-text("Przypisz"), a:has-text("Rozdział")').first();
      if (await przyciskRozdzial.isVisible({ timeout: 5000 })) {
        await przyciskRozdzial.click();
        await page.waitForLoadState('networkidle');

        const pracownikSelect = page.locator('select[name*="pracownik"], select[id*="pracownik"], [data-testid="pracownik-select"]').first();
        if (await pracownikSelect.isVisible({ timeout: 3000 })) {
          await pracownikSelect.click();
          await page.locator('option:has-text("Roman"), option:has-text("Mazowiecki")').first().click();

          const zatwierdzButton = page.locator('button:has-text("Zatwierdź"), button:has-text("Przypisz"), button[type="submit"]').first();
          await zatwierdzButton.click();
          await page.waitForLoadState('networkidle');
        }
      }
    }
  });

  test('Krok 3: Pracownik merytoryczny zakłada sprawę na podstawie korespondencji', async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login(TEST_USERS.merytoryczni.romanMazowiecki.login, TEST_USERS.merytoryczni.romanMazowiecki.password);
    await loginPage.expectLoggedIn();

    const sprawyPage = new SprawyPage(page);
    await sprawyPage.goto();
    await sprawyPage.expectLoaded();
    await sprawyPage.kliknijNowaSprawa();

    const nowaSprawaPage = new NowaSprawaPage(page);
    await nowaSprawaPage.expectLoaded();

    const testData = createTestData();
    tytulSprawy = testData.tytul;

    await nowaSprawaPage.wypelnijFormularz({
      tytul: testData.tytul,
      termin: getFutureDate(30),
      kategoria: 'Sprawy administracyjne',
      jrwa: '100 - Sprawy ogólne',
      opis: `Sprawa założona na podstawie korespondencji: ${numerPrzesylki}\n${testData.opis}`,
    });

    await nowaSprawaPage.zapiszIZamknij();
    await expect(page).toHaveURL(/\/sprawy/);
  });

  test('Krok 4: Kierownik akceptuje/ podpisuje sprawę', async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login(TEST_USERS.kierownicy.dorotaWielkopolska.login, TEST_USERS.kierownicy.dorotaWielkopolska.password);
    await loginPage.expectLoggedIn();

    await page.goto('/zadania');
    await page.waitForLoadState('networkidle');

    const zadanieSprawa = page.locator(`text=${tytulSprawy}`).first();
    if (await zadanieSprawa.isVisible({ timeout: 5000 })) {
      await zadanieSprawa.click();
      await page.waitForLoadState('networkidle');

      const przyciskAkceptuj = page.locator('button:has-text("Akceptuj"), button:has-text("Podpisz"), button:has-text("Zatwierdź")').first();
      if (await przyciskAkceptuj.isVisible({ timeout: 3000 })) {
        await przyciskAkceptuj.click();
        await page.waitForLoadState('networkidle');
      }
    }
  });

  test('Krok 5: Weryfikacja - sprawa widoczna w systemie', async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login(TEST_USERS.merytoryczni.romanMazowiecki.login, TEST_USERS.merytoryczni.romanMazowiecki.password);
    await loginPage.expectLoggedIn();

    const sprawyPage = new SprawyPage(page);
    await sprawyPage.goto();
    await sprawyPage.expectLoaded();
    await sprawyPage.wyszukajSprawe(tytulSprawy);

    const istnieje = await sprawyPage.sprawdzCzySprawaIstnieje(tytulSprawy);
    expect(istnieje).toBeTruthy();
  });
});