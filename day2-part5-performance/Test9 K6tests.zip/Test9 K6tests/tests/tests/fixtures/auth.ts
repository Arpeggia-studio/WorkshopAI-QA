import { test as base, Page, mergeTests } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { DashboardPage } from '../pages/DashboardPage';
import { TEST_USERS, TestUser } from '../test-data/users';

type AuthFixtures = {
  loginPage: LoginPage;
  dashboardPage: DashboardPage;
  loggedInPage: Page;
  user: TestUser;
};

export const test = base.extend<AuthFixtures>({
  loginPage: async ({ page }, use) => {
    const loginPage = new LoginPage(page);
    await use(loginPage);
  },

  dashboardPage: async ({ page }, use) => {
    const dashboardPage = new DashboardPage(page);
    await use(dashboardPage);
  },

  user: [TEST_USERS.kancelaria.zofiaPodkarpacka, { option: true }],

  loggedInPage: async ({ page, user }, use) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login(user.login, user.password);
    await loginPage.expectLoggedIn();
    await use(page);
  },
});

export const testAsKancelaria = mergeTests(
  test,
  test.extend<AuthFixtures>({
    user: TEST_USERS.kancelaria.zofiaPodkarpacka,
  })
);

export const testAsMerytoryczny = mergeTests(
  test,
  test.extend<AuthFixtures>({
    user: TEST_USERS.merytoryczni.romanMazowiecki,
  })
);

export const testAsKierownik = mergeTests(
  test,
  test.extend<AuthFixtures>({
    user: TEST_USERS.kierownicy.dorotaWielkopolska,
  })
);

export { expect } from '@playwright/test';