import { testAsKierownik as test, expect } from './fixtures/auth';
import { KorespondencjaPrzychodzacaPage } from './pages/KorespondencjaPrzychodzacaPage';
import { createTestData, getTodayDate } from './utils/helpers';

test.describe('Rozdzielanie korespondencji - Kierownik', () => {
  test('powinno wyświetlić korespondencję do rozdzielenia', async ({ loggedInPage }) => {
    const page = new KorespondencjaPrzychodzacaPage(loggedInPage);
    await page.goto();
    await page.expectLoaded();
    
    await expect(page.tabelaPrzesylek).toBeVisible();
  });

  test('powinno umożliwić przypisanie pisma do pracownika merytorycznego', async ({ loggedInPage }) => {
    const listaPage = new KorespondencjaPrzychodzacaPage(loggedInPage);
    await listaPage.goto();
    await listaPage.expectLoaded();
    
    const testData = createTestData();
    await listaPage.wyszukajPrzesylke(testData.tytul);
    
    const istnieje = await listaPage.sprawdzCzyPrzesylkaIstnieje(testData.tytul);
    if (istnieje) {
      await listaPage.otworzPrzesylke(testData.tytul);
      await loggedInPage.waitForLoadState('networkidle');
      
      const przyciskPrzypisz = loggedInPage.locator('button:has-text("Przypisz"), button:has-text("Rozdział"), a:has-text("Przypisz")').first();
      if (await przyciskPrzypisz.isVisible({ timeout: 3000 })) {
        await przyciskPrzypisz.click();
        await loggedInPage.waitForLoadState('networkidle');
        
        const pracownikSelect = loggedInPage.locator('select[name*="pracownik"], select[id*="pracownik"], [data-testid="pracownik-select"]').first();
        if (await pracownikSelect.isVisible({ timeout: 3000 })) {
          await pracownikSelect.click();
          await loggedInPage.locator('option:has-text("Roman"), option:has-text("Aleksandra")').first().click();
          
          const zatwierdzButton = loggedInPage.locator('button:has-text("Zatwierdź"), button:has-text("Przypisz"), button[type="submit"]').first();
          await zatwierdzButton.click();
          await loggedInPage.waitForLoadState('networkidle');
        }
      }
    }
  });
});

test.describe('Akceptacja i podpisywanie - Kierownik', () => {
  test('powinno wyświetlić dokumenty do akceptacji', async ({ loggedInPage }) => {
    await loggedInPage.goto('/zadania');
    await loggedInPage.waitForLoadState('networkidle');
    
    const zadaniaDoAkceptacji = loggedInPage.locator('text=Do akceptacji, text=Do podpisu, [data-testid="do-akceptacji"]').first();
    if (await zadaniaDoAkceptacji.isVisible({ timeout: 5000 })) {
      await expect(zadaniaDoAkceptacji).toBeVisible();
    }
  });
});