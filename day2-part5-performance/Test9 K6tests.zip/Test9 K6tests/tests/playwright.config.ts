import { defineConfig, devices } from '@playwright/test';

const useSystemBrowser = !!process.env.USE_SYSTEM_BROWSER;

export default defineConfig({
  testDir: './tests',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: [
    ['html', { outputFolder: 'playwright-report', open: 'never' }],
    ['json', { outputFile: 'test-results/results.json' }],
    ['line']
  ],
  use: {
    baseURL: 'https://ezdrp-web.demo.ezdrp.gov.pl',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    actionTimeout: 15000,
    navigationTimeout: 30000,
  },
  projects: [
    {
      name: 'chromium',
      use: { 
        ...devices['Desktop Chrome'],
        channel: useSystemBrowser ? 'chrome' : undefined,
      },
    },
    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },
    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
    },
    {
      name: 'msedge',
      use: { 
        ...devices['Desktop Edge'],
        channel: useSystemBrowser ? 'msedge' : undefined,
      },
    },
  ],
  webServer: undefined,
  timeout: 60000,
  expect: {
    timeout: 10000,
  },
});