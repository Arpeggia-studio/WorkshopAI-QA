# k6 Performance Tests — EZD RP Demo

Workflow agentowy do tworzenia testów wydajnościowych k6 w 4 krokach:

1. **Dokumentacja** na bazie scenariuszy testowych (Playwright → k6)
2. **Metodologia** scenariuszy wydajnościowych
3. **Kod k6** scenariuszy
4. **Review** i kontrola spójności

Szczegóły workflow: [`AGENT-WORKFLOW.md`](./AGENT-WORKFLOW.md)

## Wymagania

- [k6](https://k6.io/docs/get-started/installation/) >= 0.50 (`k6 version`)
- Node.js 18+ (tylko do skryptu review, nie do samych testów k6)
- PowerShell 7+ (Windows) lub bash (Linux/macOS)

## Szybki start

```powershell
cd tests-performance

# 1. Sprawdź środowisko
.\run-workflow.ps1 -Stage check

# 2. Cały workflow: docs -> metodologia -> kod (verify) -> review
.\run-workflow.ps1 -Stage all

# 3. Pojedynczy test k6
k6 run scenarios/01-smoke-login.js

# 4. Test z nadpisaniem parametrów
k6 run -e BASE_URL=https://ezdrp-web.demo.ezdrp.gov.pl -e VUS=10 -e DURATION=1m scenarios/02-load-korespondencja.js

# 5. Samo review spójności (bez k6)
.\run-workflow.ps1 -Stage review
# albo bezpośrednio:
node scripts/review.mjs
```

Na Linux/macOS: `./run-workflow.sh <check|docs|methodology|code|review|all>`.

## Struktura

```
tests-performance/
├── README.md               # ten plik
├── AGENT-WORKFLOW.md       # instrukcja workflow dla agenta (4 kroki)
├── package.json            # skrypty npm (alternatywa dla ps1/sh)
├── config.js               # wspólna konfiguracja k6 (BASE_URL, progi, użytkownicy)
├── docs/
│   ├── 01-SCENARIUSZE.md   # KROK 1: dokumentacja na bazie scenariuszy Playwright
│   ├── 02-METODOLOGIA.md   # KROK 2: metodologia performance
│   └── 04-REVIEW-RAPORT.md # KROK 4: raport z review (wypełnia agent)
├── prompts/
│   ├── 01-agent-dokumentacja.md  # prompt: agent tworzy dokumentację
│   ├── 02-agent-metodologia.md   # prompt: agent tworzy metodologię
│   ├── 03-agent-kod.md           # prompt: agent tworzy kod k6
│   └── 04-agent-review.md        # prompt: agent robi review
├── scenarios/
│   ├── common.js                 # współdzielone helpery (users, checks, thresholds)
│   ├── 01-smoke-login.js         # smoke: logowanie + dashboard
│   ├── 02-load-korespondencja.js # load: korespondencja przychodząca (kancelaria)
│   ├── 03-load-sprawy.js         # load: sprawy (pracownik merytoryczny)
│   ├── 04-stress-mixed.js        # stress: ruch mieszany wszystkich ról
│   └── 05-spike-dashboard.js     # spike: nagły skok na dashboard
├── scripts/
│   └── review.mjs                # automatyczna kontrola spójności (KROK 4)
├── results/                      # wyniki k6 (JSON), ignorowane przez git poza .gitkeep
└── run-workflow.ps1 / run-workflow.sh  # runner całego workflow
```

## Scenariusze k6

| Plik | Typ | VU / czas (default) | Mapowanie z Playwright |
|------|-----|---------------------|------------------------|
| `01-smoke-login.js` | smoke | 1 VU, 30s | `login.spec.ts` — logowanie 3 ról |
| `02-load-korespondencja.js` | load | do 20 VU, ~4m | `korespondencja-przychodzaca.spec.ts` |
| `03-load-sprawy.js` | load | do 20 VU, ~4m | `sprawy.spec.ts` |
| `04-stress-mixed.js` | stress | do 100 VU, ~9m | `e2e-pelny-cykl.spec.ts`, `kierownik.spec.ts` |
| `05-spike-dashboard.js` | spike | 0→50→0, ~3m | `sesja-i-wspolpraca.spec.ts` (wielu userów naraz) |

Wszystkie scenariusze przyjmują zmienne środowiskowe:

| Zmienna | Default | Opis |
|---------|---------|------|
| `BASE_URL` | `https://ezdrp-web.demo.ezdrp.gov.pl` | adres testowanego demo |
| `VUS` | zależne od scenariusza | nadpisuje liczbę VU (tylko dla executorów `constant-vus` tam gdzie wspierane) |
| `DURATION` | zależna od scenariusza | nadpisuje czas trwania |
| `THINK_MIN` / `THINK_MAX` | `1` / `3` | think-time między requestami (s) |

## Progi (SLO)

Zdefiniowane w `config.js` i powielone w każdym scenariuszu:

- `http_req_failed` < 1% (smoke) / < 2% (load) / < 5% (stress/spike)
- `http_req_duration` p(95) < 2000 ms (smoke/load), < 3000 ms (stress/spike)
- `checks` success rate > 99% (smoke) / > 98% (load) / > 95% (stress)

Szczegóły w [`docs/02-METODOLOGIA.md`](./docs/02-METODOLOGIA.md).

## Uwagi o Demo EZD RP

1. Reset systemu w godzinach parzystych — nie planuj testów soak na te godziny.
2. Blokada logowania po 3 błędnych próbach — scenariusze k6 używają **poprawnych** kont i nie testują negatywnego logowania pod obciążeniem.
3. Brak izolacji danych — wyniki list mogą się różnić między runami, asercje są na status/treść strony, nie na dokładną liczbę rekordów.
4. Testy k6 są na poziomie protokołu HTTP (GET stron), nie klikają w UI jak Playwright — to zamierzone (wydajność, nie E2E).
