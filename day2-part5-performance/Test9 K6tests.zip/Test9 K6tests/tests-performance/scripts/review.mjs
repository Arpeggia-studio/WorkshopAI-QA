// KROK 4 — automatyczna kontrola spójności (node scripts/review.mjs).
// Sprawdza: thresholds vs config.js/SLO, użycie common.js, tagi, ENV, strukturę options.
// Exit 0 = PASS, exit 1 = FAIL (lista błędów na stdout). Bez zależności npm.
import { readFileSync, readdirSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const scenariosDir = join(root, 'scenarios');
const errors = [];
const warnings = [];

function fail(msg) { errors.push(msg); }
function warn(msg) { warnings.push(msg); }

// 1. Pliki bazowe workflow
for (const f of [
  'README.md', 'AGENT-WORKFLOW.md', 'package.json', 'config.js',
  'docs/01-SCENARIUSZE.md', 'docs/02-METODOLOGIA.md', 'docs/04-REVIEW-RAPORT.md',
  'scenarios/common.js',
  'prompts/01-agent-dokumentacja.md', 'prompts/02-agent-metodologia.md',
  'prompts/03-agent-kod.md', 'prompts/04-agent-review.md',
]) {
  if (!existsSync(join(root, f))) fail(`brak wymaganego pliku: ${f}`);
}

// 2. SLO w config.js
const configSrc = readFileSync(join(root, 'config.js'), 'utf8');
for (const key of ['smoke', 'load', 'stress', 'spike']) {
  if (!configSrc.includes(`${key}:`)) fail(`config.js: brak SLO.${key}`);
}
const expectedThresholds = {
  smoke: ['rate<0.01', 'p(95)<2000', 'rate>0.99'],
  load: ['rate<0.02', 'p(95)<2000', 'rate>0.98'],
  stress: ['rate<0.05', 'p(95)<3000', 'rate>0.95'],
  spike: ['rate<0.05', 'p(95)<3000', 'rate>0.95'],
};
// Kolejność scenariuszy → oczekiwany typ SLO
const expectedType = { '01': 'smoke', '02': 'load', '03': 'load', '04': 'stress', '05': 'spike' };

// 3. Scenariusze
const files = readdirSync(scenariosDir).filter((f) => /^\d{2}-.*\.js$/.test(f)).sort();
if (files.length === 0) fail('scenarios/: brak plików NN-nazwa.js');
if (!existsSync(join(scenariosDir, 'common.js'))) fail('scenarios/common.js nie istnieje');

for (const file of files) {
  const src = readFileSync(join(scenariosDir, file), 'utf8');
  const prefix = file.slice(0, 2);
  const label = `scenarios/${file}`;

  // 3a. importy common.js + config.js
  if (!src.includes('./common.js')) fail(`${label}: brak importu ./common.js`);
  if (!src.includes('../config.js') || !src.includes('SLO')) fail(`${label}: brak importu SLO z ../config.js`);
  if (!src.includes('checkPage(')) fail(`${label}: nie używa checkPage()`);
  if (!src.includes('think()')) fail(`${label}: nie używa think()`);
  if (!src.includes('getBaseUrl()')) fail(`${label}: nie używa getBaseUrl()`);
  if (!src.includes('SharedArray') || !src.includes('pickUser(')) fail(`${label}: brak rotacji kont (SharedArray + pickUser)`);

  // 3b. zakazy: sekrety, node_modules, twarde IP/adresy
  if (/EzdTest1234!/.test(src)) fail(`${label}: hasło na sztywno — przenieś do common.js`);
  if (/require\(|from ['"]fs['"]|from ['"]path['"]|process\.env/.test(src)) fail(`${label}: moduły node w kodzie k6`);
  if (/https?:\/\/(?!.*BASE_URL|.*__ENV)/.test(src) && !src.includes('BASE_URL')) warn(`${label}: możliwy hardkod URL`);

  // 3c. tagi / checkPage z nazwą
  const tags = [...src.matchAll(/checkPage\([^,]+,\s*['"]([^'"]+)['"]/g)].map((m) => m[1]);
  if (tags.length === 0) fail(`${label}: brak tagowanych requestów (checkPage url, 'tag')`);
  if (!tags.includes('login') || !tags.includes('dashboard')) warn(`${label}: brak tagów login+dashboard`);

  // 3d. thresholds zgodne z typem
  const want = expectedType[prefix];
  if (want) {
    if (!src.includes(`SLO.${want}`)) fail(`${label}: options.thresholds powinno używać SLO.${want} (typ ${want})`);
    for (const t of expectedThresholds[want]) {
      if (!configSrc.replace(/\s+/g, '').includes(t.replace(/\s+/g, ''))) fail(`config.js: SLO.${want} nie zawiera progu ${t}`);
    }
  }

  // 3e. options: smoke = vus+duration, reszta = stages
  if (want === 'smoke') {
    if (!/vus\s*:/.test(src) || !/duration\s*:/.test(src)) fail(`${label}: smoke wymaga vus + duration w options`);
  } else if (want) {
    if (!/stages\s*:\s*\[/.test(src)) fail(`${label}: test ${want} wymaga stages w options`);
  }

  // 3f. ENV
  if (!src.includes('__ENV.VUS') && want === 'smoke') warn(`${label}: smoke powinien wspierać __ENV.VUS`);
  void want;
}

// 4. common.js — wymagane helpery
const commonSrc = readFileSync(join(scenariosDir, 'common.js'), 'utf8');
for (const fn of ['getBaseUrl', 'getUsers', 'checkPage', 'think', 'pickUser']) {
  if (!commonSrc.includes(`export function ${fn}`)) fail(`common.js: brak export function ${fn}`);
}

// 5. docs — minimalne sekcje
const doc1 = existsSync(join(root, 'docs/01-SCENARIUSZE.md')) ? readFileSync(join(root, 'docs/01-SCENARIUSZE.md'), 'utf8') : '';
for (const s of ['## 1.1', '## 1.2', '## 1.3', '## 1.4', '## 1.5']) {
  if (!doc1.includes(s)) fail(`docs/01-SCENARIUSZE.md: brak sekcji ${s}`);
}
const doc2 = existsSync(join(root, 'docs/02-METODOLOGIA.md')) ? readFileSync(join(root, 'docs/02-METODOLOGIA.md'), 'utf8') : '';
for (const s of ['## 2.1', '## 2.2', '## 2.3', '## 2.4', '## 2.5']) {
  if (!doc2.includes(s)) fail(`docs/02-METODOLOGIA.md: brak sekcji ${s}`);
}

console.log(`review.mjs: sprawdzono ${files.length} scenariuszy (${files.join(', ') || 'brak'})`);
for (const w of warnings) console.log(`WARN: ${w}`);
if (errors.length > 0) {
  console.log('WYNIK: FAIL');
  for (const e of errors) console.log(`FAIL: ${e}`);
  process.exit(1);
} else {
  console.log('WYNIK: PASS — workflow spójny (docs ↔ metodologia ↔ kod).');
}
