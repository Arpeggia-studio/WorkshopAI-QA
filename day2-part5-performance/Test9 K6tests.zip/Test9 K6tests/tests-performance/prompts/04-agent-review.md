# Prompt K4 — Agent: review i spójność wszystkich testów

Jesteś reviewerem QA. Twoim zadaniem jest sprawdzić WSZYSTKO i wypełnić `docs/04-REVIEW-RAPORT.md`.

## Procedura (po kolei, bez pomijania)

### A. Review automatyczne

```powershell
node scripts/review.mjs
```

- Exit 0 = spójne. Exit != 0 = lista błędów do naprawy (progi, tagi, importy, ENV, stages).
- Napraw kod, ponów `review.mjs` aż do exit 0.

### B. Dry-run k6 (jeśli k6 zainstalowane)

```powershell
k6 run --vus 1 --iterations 1 scenarios/01-smoke-login.js
k6 run --vus 1 --iterations 1 scenarios/02-load-korespondencja.js
k6 run --vus 1 --iterations 1 scenarios/03-load-sprawy.js
k6 run --vus 1 --iterations 1 scenarios/04-stress-mixed.js
k6 run --vus 1 --iterations 1 scenarios/05-spike-dashboard.js
```

Każdy dry-run musi zakończyć się bez błędów składni i z checkami PASS (dostępność demo!).

### C. Checklista manualna (per scenariusz)

1. [ ] `options.stages`/`vus`/`duration` == `docs/02-METODOLOGIA.md` §2.2?
2. [ ] `options.thresholds` == §2.3 dla typu testu (smoke/load/stress/spike)?
3. [ ] Wszystkie requesty mają `tags.name` i przechodzą przez `checkPage()`?
4. [ ] `BASE_URL` przez `getBaseUrl()`, konta przez `SharedArray`+`pickUser()`?
5. [ ] Brak sekretów, brak POST-ów tworzących dane, brak asercji na liczbę rekordów?
6. [ ] Przepływ zgodny z `docs/01-SCENARIUSZE.md` §1.3, role zgodne z §1.2?
7. [ ] Nowy scenariusz dopisany do `README.md` (tabela) i do `package.json` (skrypt)?

### D. Raport

Uzupełnij `docs/04-REVIEW-RAPORT.md`: data, tabela per scenariusz (PASS/FAIL + uwagi),
sekcja Uwagi (co naprawiono), wiersz w Historii. Scenariusz z FAIL nie może być scalony.

## Zasady

- Masz prawo edytować `scenarios/`, `config.js`, `common.js` żeby uzyskać spójność — ale KAŻDĄ zmianę progów/VU odnotuj też w `docs/02-METODOLOGIA.md` (docs i kod zawsze w sync).
- Nie obniżaj progów żeby "przeszło" — jeśli demo nie spełnia SLO, wpisz FAIL z dowodem (JSON z `results/`) i rekomendacją.
