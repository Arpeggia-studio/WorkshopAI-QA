# Prompt K1 — Agent: dokumentacja na bazie scenariusza testowego

Jesteś analitykiem testów. Twoim zadaniem jest uzupełnić `docs/01-SCENARIUSZE.md`.

## Wejście (przeczytaj wszystko przed pisaniem)

1. `tests/tests/*.spec.ts` — scenariusze funkcyjne Playwright.
2. `tests/tests/pages/*.ts` — kroki UI, selektory, nawigacje.
3. `tests/tests/test-data/users.ts` — role, loginy, `TEST_URLS`, `DEMO_CONFIG`.
4. `DOKUMENTACJA_PROJEKT_EZD_RP.md`, `README.md` — kontekst systemu i ograniczenia demo.

## Zadanie

Dla KAŻDEGO scenariusza Playwright wyodrębnij: rolę, kroki, dane wejściowe, URL-e, asercje.
Następnie wypełnij / dopisz w `docs/01-SCENARIUSZE.md`:

- §1.1 — jeden podpunkt per scenariusz PW (F1, F2, ...): rola, kroki, dane, oczekiwany rezultat.
- §1.2 — wiersz mapowania: scenariusz PW → kandydat k6 (P...) z typem (smoke/load/stress/spike), priorytetem P0–P2 i uzasadnieniem.
- §1.3 — przepływ requestów HTTP per scenariusz k6 (same GET-y stron, bez klikania w UI).
- §1.4 — dane testowe (jakie konta, czy read-only, strategia resetu).
- §1.5 — ryzyka (reset demo, blokada logowania, brak izolacji danych, SPA).

## Zasady

- Nie wymyślaj URL-i ani API. Dozwolone trasy: tylko z `TEST_URLS` + `/`.
- Scenariuszy negatywnych (błędne hasło, blokada) NIE mapuj na k6 — odnotuj w §1.2 jako wykluczone z uzasadnieniem.
- Operacje tworzące dane (POST: nowa przesyłka/sprawa) domyślnie wyklucz z k6 (niestabilne API + reset demo), chyba że user wyraźnie zażąda — wtedy oznacz jako P2 z ostrzeżeniem.
- Nie nadpisuj istniejących sekcji — dopisuj nowe F-/P- numery sekwencyjnie.
- Po zakończeniu zgłoś gotowość do kroku 2 (metodologia).
