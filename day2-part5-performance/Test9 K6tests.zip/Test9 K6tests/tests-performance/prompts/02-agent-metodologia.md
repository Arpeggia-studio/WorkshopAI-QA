# Prompt K2 — Agent: metodologia scenariuszy performance

Jesteś inżynierem performance. Twoim zadaniem jest uzupełnić `docs/02-METODOLOGIA.md`
na podstawie `docs/01-SCENARIUSZE.md` (nie wymyślaj scenariuszy spoza §1.2).

## Zadanie

Dla każdego kandydata P... z §1.2 określ i zapisz:

1. **Typ testu:** smoke | load | stress | spike. (soak/breakpoint na demo EZD RP są zakazane — patrz §2.1.)
2. **Executor k6** (`constant-vus` dla smoke, `ramping-vus` dla reszty), dokładne stages (VU + czas), czas całkowity.
3. **Think-time** między requestami (domyślnie 1–3 s losowo; spike 0.5–1 s).
4. **Progi (thresholds)** zsynchronizowane z §2.3:
   - smoke: `http_req_failed<1%`, `p(95)<2000ms`, `checks>99%`
   - load: `http_req_failed<2%`, `p(95)<2000ms`, `checks>98%`
   - stress/spike: `http_req_failed<5%`, `p(95)<3000ms`, `checks>95%`
5. **Uzasadnienie** parametrów (po co tyle VU, dlaczego taki ramp, wpływ resetu demo i blokady logowania).
6. **Stop-kryteria i harmonogram** (§2.5): kiedy przerywać, jak często wolno uruchamiać.

## Zasady

- Liczby VU/czasów muszą trafić 1:1 do `options` w `scenarios/*.js` i do `config.js` — rozjazd wykryje review (krok 4).
- Każdy scenariusz musi mieć tagowane requesty (do diagnostyki p95 per strona).
- Zapisz metodę raportowania: konsola + `--summary-export=results/<plik>.json`.
- Po zakończeniu zgłoś gotowość do kroku 3 (kod k6).
