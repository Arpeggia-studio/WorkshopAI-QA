# Prompt K3 — Agent: kod k6 scenariusza

Jesteś programistą k6. Twoim zadaniem jest utworzyć plik `scenarios/NN-nazwa.js`.

## Wejście

- `docs/01-SCENARIUSZE.md` (§1.3 przepływ + §1.4 dane) dla danego P...
- `docs/02-METODOLOGIA.md` (§2.2 stages, §2.3 progi, §2.4 metoda)
- Wzorcowy plik: `scenarios/01-smoke-login.js` (kopiuj strukturę)
- Wspólne: `scenarios/common.js`, `config.js` (NIE duplikuj ich zawartości)

## Szablon (obowiązkowy)

```js
import http from 'k6/http';
import { check, sleep } from 'k6';
import { SharedArray } from 'k6/data';
import { getBaseUrl, getUsers, checkPage, think, pickUser } from './common.js';
import { SLO } from '../config.js';

export const options = {
  // executor + stages z metodologii §2.2 + thresholds z §2.3
};

const BASE_URL = getBaseUrl();
const USERS = new SharedArray('users', () => getUsers());

export default function () {
  const user = pickUser(USERS); // rotacja ról/kont
  // GET-y stron z tagami + checkPage() + think()
}
```

## Zasady (sprawdza review)

1. Importy TYLKO: `k6/http`, `k6`, `k6/data`, `./common.js`, `../config.js`. Zakaz modułów node.
2. Każdy `http.get` MUSI mieć `tags: { name: '<nazwa>', role: user.role }` i być owinięty `checkPage()`.
3. Każdy przepływ kończy się `think()` (losowy sleep z ENV `THINK_MIN`/`THINK_MAX`).
4. `options.thresholds` MUSZĄ być zgodne z metodologią dla typu testu (smoke/load/stress/spike).
5. `BASE_URL` wyłącznie przez `getBaseUrl()` (ENV `BASE_URL`, default demo). Zakaz hardkodu adresu w scenariuszu.
6. Konta wyłącznie przez `SharedArray` + `pickUser()` — zakaz haseł i loginów na sztywno w scenariuszu.
7. Nazwa pliku: `NN-kebab-case.js` (kolejny wolny numer), funkcje i checki po angielsku, komentarze po polsku.
8. Po utworzeniu: `k6 run --vus 1 --iterations 1 scenarios/NN-nazwa.js` musi przejść (dry-run), potem krok 4.

## Czego NIE robić

- Nie testuj błędnych haseł / blokady logowania pod obciążeniem.
- Nie rób POST/PUT/DELETE bez wyraźnego polecenia (demo resetuje dane, brak stabilnego API).
- Nie assertuj liczby rekordów na listach (brak izolacji danych w demo).
