# AGENT-WORKFLOW — tworzenie k6 performance testów w 4 krokach

Ten plik jest instrukcją dla agenta (AI / człowiek). Każdy krok ma swój prompt
w `prompts/` i swój artefakt. Kolejność jest obowiązkowa: 1 → 2 → 3 → 4.

Uruchomienie całości:

```powershell
cd tests-performance
.\run-workflow.ps1 -Stage all
```

lub pojedyncze etapy: `-Stage check|docs|methodology|code|review`.

---

## KROK 1 — Agent tworzy dokumentację na bazie scenariusza testowego

- **Prompt:** `prompts/01-agent-dokumentacja.md`
- **Wejście:** `tests/tests/*.spec.ts`, `tests/tests/pages/*.ts`, `tests/tests/test-data/users.ts`,
  `DOKUMENTACJA_PROJEKT_EZD_RP.md`, `README.md`
- **Wyjście:** `docs/01-SCENARIUSZE.md`
- **Co robi agent:**
  1. Czyta scenariusze Playwright (login, kancelaria, sprawy, kierownik, e2e, sesje).
  2. Dla każdego wyodrębnia: rolę, kroki, dane, URL-e, oczekiwane rezultaty.
  3. Mapuje każdy scenariusz funkcyjny → kandydata na scenariusz wydajnościowy
     (tabela: scenariusz PW → typ k6 → priorytet → ryzyko).
  4. Zapisuje wynik w `docs/01-SCENARIUSZE.md` wg szablonu z promptu.
- **Weryfikacja:** `.\run-workflow.ps1 -Stage docs` sprawdza czy plik istnieje
  i zawiera wymagane sekcje (audyt automatyczny, nie zastępuje review).
- **Gotowe w repo:** `docs/01-SCENARIUSZE.md` jest już wypełnione dla EZD RP Demo.
  Agent dla nowego scenariusza dopisuje sekcję, nie nadpisuje całości.

## KROK 2 — Agent tworzy metodologię scenariuszy performance

- **Prompt:** `prompts/02-agent-metodologia.md`
- **Wejście:** `docs/01-SCENARIUSZE.md`
- **Wyjście:** `docs/02-METODOLOGIA.md`
- **Co robi agent:**
  1. Dla każdego kandydata z kroku 1 dobiera typ testu: smoke / load / stress / spike / soak / breakpoint.
  2. Definiuje: VU, ramp-up/down, czas, think-time, executory k6, progi (thresholds), SLO.
  3. Uzasadnia wybór parametrów specyfiką Demo (reset co 2h, blokada logowania, brak izolacji danych).
  4. Zapisuje w `docs/02-METODOLOGIA.md`.
- **Weryfikacja:** `.\run-workflow.ps1 -Stage methodology`.
- **Gotowe w repo:** metodologia dla 5 scenariuszy jest już zdefiniowana.
  Zmiana SLO wymaga aktualizacji **zarówno** `docs/02-METODOLOGIA.md` **jak i** `config.js`
  i wszystkich plików w `scenarios/` (pilnuje tego review z kroku 4).

## KROK 3 — Agent tworzy kod k6 scenariusza

- **Prompt:** `prompts/03-agent-kod.md`
- **Wejście:** `docs/01-SCENARIUSZE.md` + `docs/02-METODOLOGIA.md` + `scenarios/common.js` + `config.js`
- **Wyjście:** nowy plik w `scenarios/NN-nazwa.js`
- **Co robi agent:**
  1. Kopiuje strukturę z najbliższego istniejącego scenariusza (np. `01-smoke-login.js`).
  2. Używa **wyłącznie** helperów z `scenarios/common.js` (users, `getBaseUrl()`, `checkPage()`, `think()`).
  3. Definiuje `options` z executorami + `thresholds` zgodnymi z metodologią.
  4. Taguje requesty (`tag: 'login'`, `tag: 'dashboard'`, ...) i nadaje sensowne nazwy checków.
  5. Nie wstawia sekretów na sztywno — loginy przez `SharedArray`, hasło stałe demo tylko w `common.js`.
- **Weryfikacja:**
  ```powershell
  k6 run --vus 1 --iterations 1 scenarios/NN-nazwa.js   # dry-run
  .\run-workflow.ps1 -Stage code                        # dry-run wszystkich + review.mjs
  ```

## KROK 4 — Agent robi review i kontrolę spójności wszystkich testów

- **Prompt:** `prompts/04-agent-review.md`
- **Wejście:** wszystko: `docs/`, `scenarios/`, `config.js`, wynik `node scripts/review.mjs`
- **Wyjście:** `docs/04-REVIEW-RAPORT.md` (uzupełniony) + poprawki w kodzie
- **Co robi agent:**
  1. Uruchamia `node scripts/review.mjs` (automatyczna kontrola: thresholds vs metodologia,
     tagi, importy common.js, zmienne ENV, struktura options).
  2. Przechodzi checklistę z promptu (SLO, VU, think-time, brak sekretów, mapowanie PW→k6).
  3. Wpisuje wynik do `docs/04-REVIEW-RAPORT.md` (data, status PASS/FAIL per scenariusz, uwagi).
  4. Naprawia niespójności i ponawia review aż `review.mjs` zwróci exit code 0.
- **Weryfikacja:** `.\run-workflow.ps1 -Stage review` — przerywa z błędem gdy niespójne.

---

## Diagram

```
tests/tests/*.spec.ts ──[K1: dokumentacja]──▶ docs/01-SCENARIUSZE.md
                                                     │
                          ──[K2: metodologia]───────▶ docs/02-METODOLOGIA.md
                                                     │
                          ──[K3: kod k6]───────────▶ scenarios/*.js (+ config.js, common.js)
                                                     │
                          ──[K4: review]───────────▶ scripts/review.mjs ✅ + docs/04-REVIEW-RAPORT.md
```

## Zasady dla agenta

1. Nie pomijaj kroków. Każdy krok czyta artefakt poprzedniego.
2. Nie wymyślaj URL-i ani API — używaj tras z `tests/tests/test-data/users.ts` (`TEST_URLS`)
   i `BASE_URL=https://ezdrp-web.demo.ezdrp.gov.pl`.
3. Testy negatywne (błędne hasło, blokada) istnieją tylko w Playwright — nie powielaj ich w k6.
4. Każdy nowy scenariusz musi przejść K4 (review.mjs exit 0) zanim zostanie uznany za gotowy.
