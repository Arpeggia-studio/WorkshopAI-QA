// P1 — Smoke: logowanie + dashboard (mapowanie: F1 login.spec.ts).
// Cel: sanity-check dostępności demo po resecie. 1 VU, read-only, GET-y stron.
// Metodologia: docs/02-METODOLOGIA.md §2.2 (P1), progi: §2.3 smoke.
import { SharedArray } from 'k6/data';
import { getBaseUrl, getUsers, checkPage, think, pickUser } from './common.js';
import { ROUTES, SLO } from '../config.js';

export const options = {
  vus: __ENV.VUS ? parseInt(__ENV.VUS, 10) : 1,
  duration: __ENV.DURATION || '30s',
  thresholds: SLO.smoke,
};

const BASE_URL = getBaseUrl();
const USERS = new SharedArray('users', () => getUsers());

export default function () {
  const user = pickUser(USERS);

  // Krok 1: strona logowania (odpowiednik LoginPage.goto())
  checkPage(`${BASE_URL}${ROUTES.login}`, 'login', 2000);

  think();

  // Krok 2: dashboard (odpowiednik expectLoggedIn + DashboardPage)
  // Demo to SPA — mierzymy dostarczenie strony; tag role do analizy per rola.
  checkPage(`${BASE_URL}${ROUTES.dashboard}`, 'dashboard', 2000);

  think();
}
