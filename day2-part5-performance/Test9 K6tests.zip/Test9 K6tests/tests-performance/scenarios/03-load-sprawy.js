// P3 — Load: sprawy, rola pracownika merytorycznego (mapowanie: F3 sprawy.spec.ts).
// Przepływ: /login → /dashboard → /sprawy → /kontakty.
// Metodologia: docs/02-METODOLOGIA.md §2.2 (P3 ramping-vus ~4m), progi load §2.3.
import { SharedArray } from 'k6/data';
import { getBaseUrl, getUsers, checkPage, think, pickUser } from './common.js';
import { ROUTES, SLO } from '../config.js';

export const options = {
  stages: [
    { duration: '30s', target: 5 },
    { duration: '1m', target: 5 },
    { duration: '1m', target: 20 },
    { duration: '1m', target: 20 },
    { duration: '30s', target: 0 },
  ],
  thresholds: SLO.load,
};

const BASE_URL = getBaseUrl();
const USERS = new SharedArray('users', () => getUsers().filter((u) => u.role === 'merytoryczny'));

export default function () {
  const user = pickUser(USERS);
  void user;

  checkPage(`${BASE_URL}${ROUTES.login}`, 'login', 2000);
  think();
  checkPage(`${BASE_URL}${ROUTES.dashboard}`, 'dashboard', 2000);
  think();
  checkPage(`${BASE_URL}${ROUTES.sprawy}`, 'sprawy', 2000);
  think();
  checkPage(`${BASE_URL}${ROUTES.kontakty}`, 'kontakty', 2000);
  think();
}
