// P5 — Spike: nagły skok na dashboard (mapowanie: F6 sesja-i-wspolpraca).
// Symuluje powrót wszystkich po resecie demo: 0 → 50 VU w 30 s.
// Metodologia: docs/02-METODOLOGIA.md §2.2 (P5), progi spike §2.3.
import { SharedArray } from 'k6/data';
import { getBaseUrl, getUsers, checkPage, think, pickUser } from './common.js';
import { ROUTES, SLO } from '../config.js';

export const options = {
  stages: [
    { duration: '30s', target: 50 },
    { duration: '1m', target: 50 },
    { duration: '30s', target: 0 },
  ],
  thresholds: SLO.spike,
};

const BASE_URL = getBaseUrl();
const USERS = new SharedArray('users', () => getUsers());

export default function () {
  const user = pickUser(USERS);
  void user;

  checkPage(`${BASE_URL}${ROUTES.login}`, 'login', 3000);
  // Krótszy think niż w load — spike ma uderzyć naraz (THINK_MIN/MAX można nadpisać z ENV).
  think();
  checkPage(`${BASE_URL}${ROUTES.dashboard}`, 'dashboard', 3000);
  think();
}
