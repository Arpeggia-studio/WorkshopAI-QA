// Współdzielone helpery k6 — importowane przez WSZYSTKIE scenariusze.
// Tylko API k6 (http/check/data) — zakaz modułów node (k6 nie ma require('fs') itp.).
import http from 'k6/http';
import { check, sleep } from 'k6';
import { BASE_URL_DEFAULT } from '../config.js';

// Konta demo EZD RP (z tests/tests/test-data/users.ts). Hasło wspólne dla demo.
const DEMO_PASSWORD = 'EzdTest1234!';

const USERS = [
  { login: 'zofiap', password: DEMO_PASSWORD, fullName: 'Zofia Podkarpacka', role: 'kancelaria' },
  { login: 'zofias', password: DEMO_PASSWORD, fullName: 'Zofia Slaska', role: 'kancelaria' },
  { login: 'romanm', password: DEMO_PASSWORD, fullName: 'Roman Mazowiecki', role: 'merytoryczny' },
  { login: 'aleksandrad', password: DEMO_PASSWORD, fullName: 'Aleksandra Dolnoslaska', role: 'merytoryczny' },
  { login: 'dorotaw', password: DEMO_PASSWORD, fullName: 'Dorota Wielkopolska', role: 'kierownik' },
];

export function getUsers() {
  return USERS;
}

// Rotacja kont po VU/iteracji — deterministyczna, bez random hotspotów.
export function pickUser(users) {
  const idx = (__VU + __ITER) % users.length;
  return users[idx];
}

export function getBaseUrl() {
  return __ENV.BASE_URL || BASE_URL_DEFAULT;
}

export function getThinkRange() {
  const min = parseFloat(__ENV.THINK_MIN || '1');
  const max = parseFloat(__ENV.THINK_MAX || '3');
  return { min, max };
}

// Think-time symulujący człowieka + ochrona współdzielonego demo.
export function think() {
  const { min, max } = getThinkRange();
  sleep(min + Math.random() * Math.max(max - min, 0.1));
}

// GET strony z tagami + standardowe checki (status, czas, marker treści).
// sloMs: próg czasu z metodologii (2000 smoke/load, 3000 stress/spike).
export function checkPage(url, tag, sloMs) {
  const res = http.get(url, { tags: { name: tag } });
  const ok = check(res, {
    [`${tag}: status 2xx/3xx`]: (r) => r.status >= 200 && r.status < 400,
    [`${tag}: czas < ${sloMs}ms`]: (r) => r.timings.duration < sloMs,
    [`${tag}: body niepuste`]: (r) => r.body && r.body.length > 0,
  });
  return { res, ok };
}
