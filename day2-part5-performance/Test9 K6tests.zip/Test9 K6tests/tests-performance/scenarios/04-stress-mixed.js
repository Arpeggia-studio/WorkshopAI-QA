// P4 — Stress: ruch mieszany wszystkich ról (mapowanie: F2+F3+F4+F5, e2e-pelny-cykl).
// Każdy VU losuje profil co iterację: kancelaria / merytoryczny / kierownik.
// Metodologia: docs/02-METODOLOGIA.md §2.2 (P4 do 100 VU ~9m), progi stress §2.3.
// UWAGA: uruchamiać max 1x/h, poza resetem demo (godziny parzyste).
import { SharedArray } from 'k6/data';
import { getBaseUrl, getUsers, checkPage, think, pickUser } from './common.js';
import { ROUTES, SLO } from '../config.js';

export const options = {
  stages: [
    { duration: '1m', target: 20 },
    { duration: '2m', target: 20 },
    { duration: '2m', target: 50 },
    { duration: '2m', target: 50 },
    { duration: '1m', target: 100 },
    { duration: '1m', target: 0 },
  ],
  thresholds: SLO.stress,
};

const BASE_URL = getBaseUrl();
const USERS = new SharedArray('users', () => getUsers());

function profilKancelaria() {
  checkPage(`${BASE_URL}${ROUTES.korespondencjaPrzychodzaca}`, 'korespondencja', 3000);
  think();
  checkPage(`${BASE_URL}${ROUTES.wyszukiwarka}`, 'wyszukiwarka', 3000);
  think();
}

function profilMerytoryczny() {
  checkPage(`${BASE_URL}${ROUTES.sprawy}`, 'sprawy', 3000);
  think();
  checkPage(`${BASE_URL}${ROUTES.kontakty}`, 'kontakty', 3000);
  think();
}

function profilKierownik() {
  checkPage(`${BASE_URL}${ROUTES.zadania}`, 'zadania', 3000);
  think();
  checkPage(`${BASE_URL}${ROUTES.korespondencjaPrzychodzaca}`, 'korespondencja', 3000);
  think();
}

export default function () {
  const user = pickUser(USERS);

  checkPage(`${BASE_URL}${ROUTES.login}`, 'login', 3000);
  think();
  checkPage(`${BASE_URL}${ROUTES.dashboard}`, 'dashboard', 3000);
  think();

  if (user.role === 'kancelaria') {
    profilKancelaria();
  } else if (user.role === 'merytoryczny') {
    profilMerytoryczny();
  } else {
    profilKierownik();
  }
}
