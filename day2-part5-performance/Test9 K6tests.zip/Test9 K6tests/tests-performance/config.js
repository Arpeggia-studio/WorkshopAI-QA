// Wspólna konfiguracja k6 — EZD RP Demo.
// Single source of truth dla SLO. Scenariusze importują SLO i MUSZĄ używać
// wartości stąd (sprawdza scripts/review.mjs + docs/02-METODOLOGIA.md §2.3).

export const BASE_URL_DEFAULT = 'https://ezdrp-web.demo.ezdrp.gov.pl';

// Progi per typ testu — 1:1 z docs/02-METODOLOGIA.md §2.3
export const SLO = {
  smoke: {
    http_req_failed: ['rate<0.01'],
    http_req_duration: ['p(95)<2000'],
    checks: ['rate>0.99'],
  },
  load: {
    http_req_failed: ['rate<0.02'],
    http_req_duration: ['p(95)<2000'],
    checks: ['rate>0.98'],
  },
  stress: {
    http_req_failed: ['rate<0.05'],
    http_req_duration: ['p(95)<3000'],
    checks: ['rate>0.95'],
  },
  spike: {
    http_req_failed: ['rate<0.05'],
    http_req_duration: ['p(95)<3000'],
    checks: ['rate>0.95'],
  },
};

// Trasy z tests/tests/test-data/users.ts (TEST_URLS) — nie dodawać nowych bez K1.
export const ROUTES = {
  login: '/login',
  dashboard: '/dashboard',
  korespondencjaPrzychodzaca: '/korespondencja/przychodzaca',
  korespondencjaWychodzaca: '/korespondencja/wychodzaca',
  sprawy: '/sprawy',
  wyszukiwarka: '/wyszukiwarka',
  kontakty: '/kontakty',
  zadania: '/zadania',
};
