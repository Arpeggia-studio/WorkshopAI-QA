#!/usr/bin/env bash
# Runner workflow k6 (Linux/macOS). Użycie: ./run-workflow.sh [check|docs|methodology|code|review|all]
set -euo pipefail
STAGE="${1:-all}"
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

stage_check() {
  echo "== check: środowisko =="
  node --version
  command -v k6 >/dev/null && k6 version || echo "WARN: brak k6 (review zadziała)"
  for f in README.md AGENT-WORKFLOW.md package.json config.js scenarios/common.js scripts/review.mjs; do
    test -f "$f" || { echo "check FAIL: brak $f"; exit 1; }
  done
  echo "check OK"
}
stage_docs() {
  echo "== K1 docs =="
  test -f docs/01-SCENARIUSZE.md || { echo "K1 FAIL"; exit 1; }
  for s in "## 1.1" "## 1.2" "## 1.3" "## 1.4" "## 1.5"; do
    grep -qF "$s" docs/01-SCENARIUSZE.md || { echo "K1 FAIL: brak $s"; exit 1; }
  done
  echo "K1 OK"
}
stage_methodology() {
  echo "== K2 metodologia =="
  test -f docs/02-METODOLOGIA.md || { echo "K2 FAIL"; exit 1; }
  for s in "## 2.1" "## 2.2" "## 2.3" "## 2.4" "## 2.5"; do
    grep -qF "$s" docs/02-METODOLOGIA.md || { echo "K2 FAIL: brak $s"; exit 1; }
  done
  echo "K2 OK"
}
stage_review() {
  echo "== K4 review =="
  node scripts/review.mjs
}
stage_code() {
  echo "== K3 kod: dry-run =="
  if ! command -v k6 >/dev/null; then
    echo "WARN: brak k6 — samo review"
    stage_review; return
  fi
  for f in scenarios/??-*.js; do
    echo "-- dry-run: $f"
    k6 run --vus 1 --iterations 1 "$f"
  done
  echo "K3 dry-run OK"
  stage_review
}
case "$STAGE" in
  check) stage_check ;;
  docs) stage_docs ;;
  methodology) stage_methodology ;;
  code) stage_code ;;
  review) stage_review ;;
  all) stage_check; stage_docs; stage_methodology; stage_code; echo "WORKFLOW ALL: PASS" ;;
  *) echo "użycie: $0 [check|docs|methodology|code|review|all]"; exit 1 ;;
esac
