<# Tarczowy runner workflow k6 (Windows / PowerShell 7+).
Użycie:
  .\run-workflow.ps1 -Stage check        # tylko sprawdzenie środowiska
  .\run-workflow.ps1 -Stage docs         # K1: weryfikacja dokumentacji
  .\run-workflow.ps1 -Stage methodology  # K2: weryfikacja metodologii
  .\run-workflow.ps1 -Stage code         # K3: dry-run k6 + review
  .\run-workflow.ps1 -Stage review       # K4: review spójności
  .\run-workflow.ps1 -Stage all          # wszystko po kolei (default)
#>
param(
  [ValidateSet('check', 'docs', 'methodology', 'code', 'review', 'all')]
  [string]$Stage = 'all'
)

$ErrorActionPreference = 'Stop'
$Root = $PSScriptRoot
Set-Location -LiteralPath $Root

function Test-StageDocs {
  Write-Host '== K1 docs: weryfikacja docs/01-SCENARIUSZE.md ==' -ForegroundColor Cyan
  $f = Join-Path $Root 'docs/01-SCENARIUSZE.md'
  if (-not (Test-Path -LiteralPath $f)) { throw "K1 FAIL: brak $f (prompt: prompts/01-agent-dokumentacja.md)" }
  $c = Get-Content -LiteralPath $f -Raw
  foreach ($s in '## 1.1', '## 1.2', '## 1.3', '## 1.4', '## 1.5') {
    if ($c -notlike "*$s*") { throw "K1 FAIL: brak sekcji $s w 01-SCENARIUSZE.md" }
  }
  Write-Host 'K1 OK' -ForegroundColor Green
}

function Test-StageMethodology {
  Write-Host '== K2 metodologia: weryfikacja docs/02-METODOLOGIA.md ==' -ForegroundColor Cyan
  $f = Join-Path $Root 'docs/02-METODOLOGIA.md'
  if (-not (Test-Path -LiteralPath $f)) { throw "K2 FAIL: brak $f (prompt: prompts/02-agent-metodologia.md)" }
  $c = Get-Content -LiteralPath $f -Raw
  foreach ($s in '## 2.1', '## 2.2', '## 2.3', '## 2.4', '## 2.5') {
    if ($c -notlike "*$s*") { throw "K2 FAIL: brak sekcji $s w 02-METODOLOGIA.md" }
  }
  Write-Host 'K2 OK' -ForegroundColor Green
}

function Test-StageReview {
  Write-Host '== K4 review: node scripts/review.mjs ==' -ForegroundColor Cyan
  node scripts/review.mjs
  if ($LASTEXITCODE -ne 0) { throw "K4 FAIL: review.mjs zwrócił $LASTEXITCODE — patrz FAIL powyżej" }
  Write-Host 'K4 OK' -ForegroundColor Green
}

function Test-StageCode {
  Write-Host '== K3 kod: dry-run scenariuszy k6 ==' -ForegroundColor Cyan
  $k6 = Get-Command k6 -ErrorAction SilentlyContinue
  if (-not $k6) {
    Write-Warning 'k6 nie znalezione w PATH — pomijam dry-run, uruchamiam samo review (zainstaluj k6: https://k6.io/docs/get-started/installation/).'
    Test-StageReview
    return
  }
  $scenarios = Get-ChildItem -LiteralPath (Join-Path $Root 'scenarios') -Filter '??-*.js' | Sort-Object Name
  if ($scenarios.Count -eq 0) { throw 'K3 FAIL: brak plików scenarios/NN-*.js' }
  foreach ($s in $scenarios) {
    Write-Host "-- dry-run: scenarios/$($s.Name)" -ForegroundColor DarkCyan
    & k6 run --vus 1 --iterations 1 "scenarios/$($s.Name)"
    if ($LASTEXITCODE -ne 0) { throw "K3 FAIL: dry-run $($s.Name) zwrócił $LASTEXITCODE" }
  }
  Write-Host 'K3 dry-run OK' -ForegroundColor Green
  Test-StageReview
}

function Test-Check {
  Write-Host '== check: środowisko ==' -ForegroundColor Cyan
  node --version
  $k6 = Get-Command k6 -ErrorAction SilentlyContinue
  if ($k6) { k6 version } else { Write-Warning 'k6 BRAK — testy k6 nie uruchomią się (review zadziała).' }
  $files = @('README.md', 'AGENT-WORKFLOW.md', 'package.json', 'config.js', 'scenarios/common.js', 'scripts/review.mjs')
  foreach ($f in $files) {
    if (-not (Test-Path -LiteralPath (Join-Path $Root $f))) { throw "check FAIL: brak $f" }
  }
  Write-Host 'check OK' -ForegroundColor Green
}

switch ($Stage) {
  'check' { Test-Check }
  'docs' { Test-StageDocs }
  'methodology' { Test-StageMethodology }
  'code' { Test-StageCode }
  'review' { Test-StageReview }
  'all' {
    Test-Check
    Test-StageDocs
    Test-StageMethodology
    Test-StageCode
    Write-Host 'WORKFLOW ALL: PASS' -ForegroundColor Green
  }
}
