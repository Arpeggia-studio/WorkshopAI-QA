# KROK 4 — Raport review i spójności

> Wypełnia agent w kroku 4 (`prompts/04-agent-review.md`) po uruchomieniu `node scripts/review.mjs`.
> Każdy nowy scenariusz dopisuje wiersz w tabeli i przechodzi na PASS zanim zostanie scalony.

## Ostatnie review

- **Data:** 2026-09-08
- **Zakres:** P1–P5 (5 scenariuszy), `config.js`, `scenarios/common.js`, `docs/01`, `docs/02`
- **Narzędzie:** `node scripts/review.mjs` → exit 0 (PASS)
- **Dry-run k6:** `k6 run --vus 1 --iterations 1` per scenariusz (wymaga zainstalowanego k6)

| Scenariusz | thresholds zgodne z metodologią | common.js używany | tagi | ENV (BASE_URL/VUS/DURATION) | Status |
|------------|----------------------------------|-------------------|------|-----------------------------|--------|
| 01-smoke-login.js | ✅ p95<2000, failed<1%, checks>99% | ✅ | ✅ login, dashboard | ✅ | PASS |
| 02-load-korespondencja.js | ✅ p95<2000, failed<2%, checks>98% | ✅ | ✅ login, dashboard, korespondencja, wyszukiwarka | ✅ | PASS |
| 03-load-sprawy.js | ✅ p95<2000, failed<2%, checks>98% | ✅ | ✅ login, dashboard, sprawy, kontakty | ✅ | PASS |
| 04-stress-mixed.js | ✅ p95<3000, failed<5%, checks>95% | ✅ | ✅ + profil, zadania | ✅ | PASS |
| 05-spike-dashboard.js | ✅ p95<3000, failed<5%, checks>95% | ✅ | ✅ login, dashboard | ✅ | PASS |

## Uwagi

- (brak — wzorzec; agent dopisuje tu niespójności i poprawki przy kolejnych zmianach)

## Historia

| Data | Zmiana | Wynik review |
|------|--------|--------------|
| 2026-09-08 | Wersja początkowa workflow (P1–P5) | PASS |
