# KROK 1 — Dokumentacja scenariuszy (Playwright → k6) — EZD RP Demo

> Artefakt kroku 1 workflow. Źródła: `tests/tests/*.spec.ts`, `tests/tests/pages/*.ts`,
> `tests/tests/test-data/users.ts`, `DOKUMENTACJA_PROJEKT_EZD_RP.md`.
> Aktualizacja: agent dopisuje sekcje wg `prompts/01-agent-dokumentacja.md`, nie nadpisuje pliku.

**System:** EZD RP Demo — https://ezdrp-web.demo.ezdrp.gov.pl
**Konta (wspólne hasło `EzdTest1234!`):** `zofiap`, `zofias` (kancelaria) · `romanm`, `aleksandrad` (merytoryczny) · `dorotaw` (kierownik)
**Trasy (z `TEST_URLS`):** `/login`, `/dashboard`, `/korespondencja/przychodzaca`, `/korespondencja/wychodzaca`, `/sprawy`, `/wyszukiwarka`, `/kontakty`, `/zadania`

## 1.1 Scenariusze źródłowe (Playwright)

### F1 — Logowanie / wylogowanie (`login.spec.ts`)
- Role: wszystkie 3. Kroki: `GET /login` → fill login+hasło → submit → assert `not.toHaveURL(/login/)` → logout → assert `/login`.
- Negatywne (tylko PW, nie k6): błędne hasło, nieistniejący user, blokada po 3 próbach (5 min).

### F2 — Kancelaria (`korespondencja-przychodzaca.spec.ts`)
- Rola: `zofiap`/`zofias`. Kroki: lista korespondencji przychodzącej → nowa przesyłka (wymagane pola) → wyszukiwanie → walidacja formularza.

### F3 — Pracownik merytoryczny (`sprawy.spec.ts`)
- Rola: `romanm`/`aleksandrad`. Kroki: lista spraw → nowa sprawa (tytuł, termin, JRWA) → wyszukiwanie → walidacja.

### F4 — Kierownik (`kierownik.spec.ts`)
- Rola: `dorotaw`. Kroki: odbiór korespondencji do rozdzielenia → przypisanie do merytorycznych → akceptacja/podpis.

### F5 — Pełny cykl E2E (`e2e-pelny-cykl.spec.ts`)
- Łańcuch: kancelaria rejestruje → kierownik rozdziela → merytoryczny zakłada sprawę → kierownik akceptuje → weryfikacja widoczności.

### F6 — Sesje i współpraca (`sesja-i-wspolpraca.spec.ts`)
- Dwóch userów na tym samym koncie, zastępstwo, odporność na refresh.

## 1.2 Mapowanie na scenariusze wydajnościowe k6

| ID k6 | Scenariusz k6 | Źródło PW | Rola / ruch | Priorytet | Plik |
|-------|---------------|-----------|-------------|-----------|------|
| P1 | Smoke: logowanie + dashboard | F1 | 1 VU, wszystkie role rotacyjnie | P0 | `scenarios/01-smoke-login.js` |
| P2 | Load: przegląd korespondencji | F2 | kancelaria, GET `/login` → `/dashboard` → `/korespondencja/przychodzaca` → `/wyszukiwarka` | P0 | `scenarios/02-load-korespondencja.js` |
| P3 | Load: przegląd spraw | F3 | merytoryczny, GET `/login` → `/dashboard` → `/sprawy` → `/wyszukiwarka` | P0 | `scenarios/03-load-sprawy.js` |
| P4 | Stress: ruch mieszany | F2+F3+F4+F5 | mix ról, wszystkie listy + dashboard | P1 | `scenarios/04-stress-mixed.js` |
| P5 | Spike: skok na dashboard | F6 | wszyscy naraz na `/dashboard` | P1 | `scenarios/05-spike-dashboard.js` |

Wyłączone z k6 (uzasadnienie): logowanie negatywne i blokada (ryzyko zablokowania kont demo),
tworzenie przesyłek/spraw metodą POST (brak stabilnego API w demo + reset co 2h unieważnia dane),
NASK Desk / QuickScan / ePUAP (aplikacje zewnętrzne, poza HTTP).

## 1.3 Przepływy requestów per scenariusz k6

- **P1:** `GET /login` → think → `GET /dashboard` → think. Checki: status 200/302, czas < SLO, treść zawiera marker (`login|zaloguj|ezd`).
- **P2:** `GET /login` → `GET /dashboard` → `GET /korespondencja/przychodzaca` → `GET /wyszukiwarka`, think 1–3 s pomiędzy.
- **P3:** `GET /login` → `GET /dashboard` → `GET /sprawy` → `GET /kontakty`, think 1–3 s pomiędzy.
- **P4:** losowy profil na VU: kancelaria (P2) / merytoryczny (P3) / kierownik (`/dashboard` → `/zadania` → `/korespondencja/przychodzaca`), losowanie co iterację.
- **P5:** tylko `GET /dashboard` (po `GET /login`), spike 0→50 VU w 30 s.

## 1.4 Dane testowe

- Użytkownicy: `SharedArray` w `scenarios/common.js` (5 kont, bez haseł w scenariuszach — hasło tylko w `common.js` jako stała demo).
- Brak kreacji danych pod obciążeniem (zgodnie z §1.2) — testy są read-only na poziomie HTTP.
- Reset demo o godzinach parzystych: runy planować na :15–:45 godziny nieparzystej.

## 1.5 Ryzyka i ograniczenia

1. Demo to SPA — `GET` zwraca shell aplikacji; prawdziwe API jest pod nieudokumentowanymi endpointami, więc mierzymy TTFB+dostarczenie strony, nie pojedyncze XHR-y.
2. Brak izolacji danych — asercje na liczbę rekordów zabronione.
3. Blokada logowania — k6 nigdy nie wysyła błędnych haseł.
4. TLS + chmura rządowa — pierwszy request iteracji może być wolniejszy (cold TLS); progi liczone na p95, nie na max.
