# KROK 2 — Metodologia scenariuszy performance — EZD RP Demo

> Artefakt kroku 2 workflow. Wejście: `docs/01-SCENARIUSZE.md`. Zmiana progów wymaga
> synchronizacji z `config.js` i `scenarios/*.js` (weryfikuje `node scripts/review.mjs`).

## 2.1 Typy testów i kiedy je uruchamiać

| Typ | Cel | Scenariusz | Kiedy |
|-----|-----|------------|-------|
| Smoke | czy demo w ogóle odpowiada, sanity po resecie | P1 | po każdym resecie demo, przed każdym load |
| Load | zachowanie pod oczekiwanym obciążeniem | P2, P3 | codziennie / na żądanie, max 20 VU |
| Stress | gdzie jest punkt załamania | P4 | okazjonalnie, poza godzinami resetu, do 100 VU |
| Spike | nagły napływ (np. wszyscy po resecie) | P5 | okazjonalnie, 0→50 VU w 30 s |
| Soak | **zakazany na demo** — reset co 2h unieważnia wynik | — | nie uruchamiać |
| Breakpoint | **zakazany na demo** — ryzyko blokady / DoS współdzielonego demo | — | nie uruchamiać |

## 2.2 Parametry (VU, czas, executory)

| Scenariusz | Executor | VU / stages | Czas | Think-time |
|------------|----------|-------------|------|------------|
| P1 smoke | `constant-vus` (wspiera `VUS`/`DURATION` z ENV) | 1 VU | 30 s (`DURATION`) | 1 s |
| P2 load korespondencja | `ramping-vus` | 0→5 (30s) →5 (1m) →20 (1m) →20 (1m) →0 (30s) | ~4 m | 1–3 s losowo |
| P3 load sprawy | `ramping-vus` | jak P2 | ~4 m | 1–3 s losowo |
| P4 stress mixed | `ramping-vus` | 0→20 (1m) →20 (2m) →50 (2m) →50 (2m) →100 (1m) →0 (1m) | ~9 m | 1–3 s losowo |
| P5 spike dashboard | `ramping-vus` | 0→50 (30s) →50 (1m) →0 (30s) | ~2–3 m | 0.5–1 s |

Start: `startTime` rozdziela scenariusze tylko wewnątrz P4 (profile ról to gałęzie w kodzie, nie osobne scenariusze k6 — prostszy raport).

## 2.3 Progi i SLO

Wspólna definicja w `config.js` (`SLO`):

- **Smoke (P1):** `http_req_failed < 1%`, `p(95) < 2000 ms`, `checks > 99%`.
- **Load (P2, P3):** `http_req_failed < 2%`, `p(95) < 2000 ms`, `checks > 98%`.
- **Stress (P4):** `http_req_failed < 5%`, `p(95) < 3000 ms`, `checks > 95%`.
- **Spike (P5):** `http_req_failed < 5%`, `p(95) < 3000 ms`, `checks > 95%`.

Reguły:
- Fail runu = przekroczenie któregokolwiek progu (k6 exit code != 0).
- p95 liczone globalnie; tagowane sub-metryki (`http_req_duration{tag:login}`) służą diagnostyce, nie gate'ują.
- Pierwsze 5 s runu ignorować przy ocenie (rozgrzewka TLS) — patrz trend, nie pojedynczy punkt.

## 2.4 Metoda pomiaru

1. Poziom protokołu HTTP (`k6/http`), nie przeglądarka. Mierzymy dostarczenie stron, nie render.
2. Każda iteracja = pełny mini-przepływ z §1.3 + `think()` 1–3 s (symulacja człowieka, ochrona demo).
3. Checki na każdy request: `status 200/302/304`, `duration < SLO`, `body zawiera marker` (case-insensitive).
4. Tagi na requestach (`login`, `dashboard`, `korespondencja`, `sprawy`, ...) — wymagane, sprawdza review.
5. Raport: konsola + `summaryTrendStats` + JSON do `results/` (`k6 run --summary-export=results/Px-<ts>.json`).

## 2.5 Harmonogram i bezpieczeństwo demo

- Uruchamiać między resetami (godziny nieparzyste, minuty :15–:45).
- Zakaz równoległego uruchamiania P4/P5 z testami Playwright na tych samych kontach.
- Stop-kryteria: `http_req_failed > 10%` przez 1 min → przerwij run (`Ctrl+C`, k6 i tak oznaczy FAIL).
- Stress/spike max 1 run na godzinę; load max 1 run na 15 min.
