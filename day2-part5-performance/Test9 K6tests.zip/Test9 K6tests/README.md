# Playwright Tests for EZD RP Demo

Automatyczne testy end-to-end dla wersji demonstracyjnej systemu EZD RP (https://ezdrp-web.demo.ezdrp.gov.pl/).

## Struktura projektu

```
tests/
├── pages/              # Page Object Models
│   ├── LoginPage.ts
│   ├── DashboardPage.ts
│   ├── KorespondencjaPrzychodzacaPage.ts
│   ├── NowaPrzesylkaPrzychodzacaPage.ts
│   ├── SprawyPage.ts
│   └── NowaSprawaPage.ts
├── fixtures/
│   └── auth.ts         # Fixtures dla autentykacji (role użytkowników)
├── test-data/
│   └── users.ts        # Dane testowe (loginy, hasła, role)
├── utils/
│   └── helpers.ts      # Funkcje pomocnicze
├── login.spec.ts              # Testy logowania/wylogowania
├── korespondencja-przychodzaca.spec.ts  # Testy kancelarii
├── sprawy.spec.ts             # Testy pracownika merytorycznego
├── kierownik.spec.ts          # Testy kierownika
├── e2e-pelny-cykl.spec.ts     # Pełny cykl życia dokumentu
└── sesja-i-wspolpraca.spec.ts # Testy sesji, resetu, współpracy
```

## Konta testowe (z dokumentacji EZD RP)

| Rola | Login | Hasło |
|------|-------|-------|
| Pracownik kancelarii (Zofia Podkarpacka) | `zofiap` | `EzdTest1234!` |
| Pracownik kancelarii (Zofia Śląska) | `zofias` | `EzdTest1234!` |
| Pracownik merytoryczny (Roman Mazowiecki) | `romanm` | `EzdTest1234!` |
| Pracownik merytoryczny (Aleksandra Dolnośląska) | `aleksandrad` | `EzdTest1234!` |
| Kierownik (Dorota Wielkopolska) | `dorotaw` | `EzdTest1234!` |

## Wymagania

- Node.js 18+
- Zainstalowane przeglądarki Playwright (`npx playwright install`)

## Instalacja

```bash
npm install
npx playwright install
```

## Uruchamianie testów

```bash
# Wszystkie testy (headless)
npm test

# Z interfejsem graficznym
npx playwright test --ui

# Tylko chromium
npx playwright test --project=chromium

# Konkretny plik testowy
npx playwright test tests/login.spec.ts

# Z konkretną rolą
npx playwright test --grep "Kierownik"

# Headed mode (widoczny przeglądarka)
npx playwright test --headed

# Debug mode
npx playwright test --debug
```

## Raporty

```bash
# Otwórz ostatni raport HTML
npx playwright show-report
```

Raporty znajdują się w `playwright-report/`, screeny i wideo w `test-results/`.

## Ważne uwagi o Demo EZD RP

1. **Reset systemu** - co godzinę parzystą (0:00, 2:00, 4:00, itd.) system wraca do stanu początkowego
2. **Blokada logowania** - 3 nieudane próby = blokada na 5 minut
3. **Brak izolacji danych** - wszyscy użytkownicy widzą dane wprowadzane przez innych
4. **Brak ePUAP/e-mail** - w demo tylko symulacja, brak rzeczywistego wysyłania
5. **Brak panelu admina** - nie można konfigurować systemu

## Scenariusze testowe

### Logowanie
- ✅ Poprawne logowanie wszystkich 3 ról
- ✅ Odrzucenie błędnych haseł
- ✅ Blokada po 3 próbach
- ✅ Wylogowanie

### Pracownik Kancelarii
- ✅ Przegląd korespondencji przychodzącej
- ✅ Tworzenie nowej przesyłki (wymagane pola)
- ✅ Wyszukiwanie przesyłek
- ✅ Walidacja formularza

### Pracownik Merytoryczny
- ✅ Przegląd spraw
- ✅ Zakładanie nowej sprawy
- ✅ Wyszukiwanie spraw
- ✅ Walidacja formularza

### Kierownik
- ✅ Rozdzielanie korespondencji
- ✅ Akceptacja/podpisywanie dokumentów

### E2E - Pełny cykl
- ✅ Rejestracja korespondencji (kancelaria)
- ✅ Rozdział do pracownika merytorycznego (kierownik)
- ✅ Założenie sprawy (merytoryczny)
- ✅ Akceptacja sprawy (kierownik)
- ✅ Weryfikacja widoczności

### Sesje i współpraca
- ✅ Dwa użytkownicy na tym samym koncie
- ✅ Praca w zastępstwie (różne konta tej samej roli)
- ✅ Odporność na odświeżenie strony

## Rozszerzanie testów

### Dodanie nowej strony (Page Object)

```typescript
// tests/pages/NowaStronaPage.ts
import { Page, Locator, expect } from '@playwright/test';

export class NowaStronaPage {
  readonly page: Page;
  readonly element: Locator;

  constructor(page: Page) {
    this.page = page;
    this.element = page.locator('selector');
  }

  async goto() {
    await this.page.goto('/sciezka');
    await this.page.waitForLoadState('networkidle');
  }

  async expectLoaded() {
    await expect(this.element).toBeVisible();
  }
}
```

### Dodanie nowego testu z konkretną rolą

```typescript
// tests/nowa-funkcja.spec.ts
import { test, expect } from './fixtures/auth';

test.describe('Nowa funkcja', () => {
  test.use({ user: require('./test-data/users').TEST_USERS.merytoryczni.romanMazowiecki });

  test('test jako pracownik merytoryczny', async ({ loggedInPage }) => {
    // test code
  });
});
```

## CI/CD

Konfiguracja w `playwright.config.ts`:
- Równoległe wykonywanie (`fullyParallel: true`)
- Retry na CI (2x)
- Raporty: HTML, JSON, line
- Trace/screenshot/video na failure

## Rozwiązywanie problemów

### Timeout przy logowaniu
- Sprawdź czy demo działa: https://ezdrp-web.demo.ezdrp.gov.pl/
- Sprawdź czy nie ma resetu systemu (godzina parzysta)

### Błędy selektorów
- Demo może się zmieniać - zaktualizuj selektory w Page Objects
- Używaj `data-testid` jeśli dostępne

### Problemy z siecią
- Zwiększ timeouty w `playwright.config.ts`
- Dodaj `waitForLoadState('networkidle')` po nawigacjach

## Licencja

Testy do celów edukacyjnych i demonstracyjnych systemu EZD RP.