---
description: Szybki audyt architektury całego repo testów E2E
agent: build
---

# /playwright-audit

Zdeleguj do subagenta `test-architect` audyt `tests/e2e/tests/` + `tests/e2e/playwright.config.ts` wg 7 obszarów z definicji agenta (duplikacja PO, helpery, fixtures, zależności, długie testy, parallel, setupy).

Wejście `$ARGUMENTS`: $ARGUMENTS (opcjonalny zakres, default: całe tests/e2e).

Zwróć tabelę znalezisk + plan P0/P1/P2. Nie refaktoruj w tym przebiegu.
