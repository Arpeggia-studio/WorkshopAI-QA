---
description: Pełny pipeline testowy Playwright: Developer -> Locator -> Reviewer (gate) -> Run+Diagnose -> Architect (okazjonalnie)
agent: build
---

# /playwright-workflow — pipeline 5 agentów

Uruchomienie: `/playwright-workflow <SCENARIUSZ> | APP_URL=... | PLIK=tests/e2e/tests/<nazwa>.spec.ts`

Wejście `$ARGUMENTS`: $ARGUMENTS

Repo: testy w `tests/e2e/` (config `tests/e2e/playwright.config.ts`, fixtures `tests/e2e/tests/fixtures/auth.ts`, dane `tests/e2e/tests/test-data/users.ts`, pages `tests/e2e/tests/pages/`). Demo EZD RP: `https://ezdrp-web.demo.ezdrp.gov.pl`, reset co godzinę parzystą, blokada 3x5min, brak izolacji danych.

## Etapy (sekwencyjnie, deleguj przez Task jako subagentów)

### 1. Playwright Developer (`playwright-developer`)
Zlecenie: na podstawie SCENARIUSZA + APP_URL przygotuj test (skill `playwright-engineering`). Oczekuj kontraktu: pliki / założenia / komenda run / lista ryzykownych lokatorów / mapowanie wymaganie->asercja.
Bez tego nie idź dalej.

### 2. Locator Specialist (`locator-specialist`)
Zlecenie: zweryfikuj/napraw TYLKO locatory z kroku 1. Oczekuj tabeli Przed/Po + plików zmienionych. Zakaz zmiany asercji biznesowych.

### 3. Test Reviewer — BRAMKA (`test-reviewer`, read-only, nie poprawia kodu)
Zlecenie: oceń 1 plik wg 8 pytań: (1) dobre assertion, (2) czy sprawdza wymaganie, (3) czy assertion wystarczający, (4) czy przejdzie mimo błędu aplikacji, (5) race conditions, (6) waitForTimeout, (7) zależność od kolejności, (8) stabilny locator.
- `APPROVED` -> idź do 4.
- `NEEDS_CHANGES` -> wróć do 1 lub 2 wg wskazania Reviewera (max 2 pętle), potem znowu Review.
- `REJECTED` -> STOP, zwróć raport użytkownikowi.

### 4. Run + Diagnose (`test-failure-diagnostician`)
Zlecenie: uruchom JEDEN test `npx playwright test <plik> --project=chromium --retries=1 --trace=on` (z `tests/e2e`) i zdiagnozuj z trace/screenshot/console/network/stack.
- PASS -> podsumuj i zamknij.
- FAIL `LOCATOR` -> raz do kroku 2, potem Review + rerun (max 2 pętle).
- FAIL `ASSERTION/TEST_DATA/TIMING` -> do kroku 1, potem Review + rerun.
- FAIL `APP_BUG/ENV_DEMO/INFRA` -> STOP, zgłoś (podepnij dowody), nie „naprawiaj” testem.
- Podejrzenie systemowe (duplikacje, współdzielone konta, seryjne setupy) -> eskaluj do 5.

### 5. Test Architect (`test-architect`) — TYLKO gdy: (a) diagnostyka wskazuje problem systemowy, (b) zmieniono >3 plików, (c) użytkownik jawnie prosi o audyt
Zlecenie: audyt 7 obszarów (duplikacja PO, zbędne helpery, złe fixtures, zależności między testami, zbyt długie testy, parallel, powtarzalne setupy) + plan P0/P1/P2. Bez refaktoru w tym przebiegu.

## Zasady
- Małe kroki: 1 scenariusz = 1 przebieg. Nie uruchamiaj całej suity.
- Pętle: max 2 powroty Developer/Locator -> Review -> rerun. Potem STOP + raport blokady.
- Reviewer i Diagnostician i Architect nie edytują kodu (mają `edit: deny`).
- Każdy krok zwraca swój kontrakt markdown — przekaż go dosłownie do następnego agenta.
- Na końcu zwróć: status (DONE/BLOCKED), pliki, komendę rerun, werdykt Reviewera, root-cause z diagnostyki (jeśli była), link do planu Architekta (jeśli był).
