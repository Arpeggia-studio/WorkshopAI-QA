# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: kierownik.spec.ts >> Akceptacja i podpisywanie - Kierownik >> powinno wyświetlić dokumenty do akceptacji
- Location: tests\kierownik.spec.ts:47:7

# Error details

```
Error: browserType.launch: Executable doesn't exist at C:\Users\sdabk\AppData\Local\ms-playwright\chromium_headless_shell-1243\chrome-headless-shell-win64\chrome-headless-shell.exe
╔════════════════════════════════════════════════════════════╗
║ Looks like Playwright was just installed or updated.       ║
║ Please run the following command to download new browsers: ║
║                                                            ║
║     npx playwright install                                 ║
║                                                            ║
║ <3 Playwright Team                                         ║
╚════════════════════════════════════════════════════════════╝
```