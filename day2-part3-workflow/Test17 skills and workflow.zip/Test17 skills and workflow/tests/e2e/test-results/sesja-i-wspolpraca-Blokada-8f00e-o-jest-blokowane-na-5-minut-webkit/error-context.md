# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: sesja-i-wspolpraca.spec.ts >> Blokada logowania po 3 nieudanych próbach >> po 3 błędnych logowaniach konto jest blokowane na 5 minut
- Location: tests\sesja-i-wspolpraca.spec.ts:111:7

# Error details

```
Error: browserType.launch: Executable doesn't exist at C:\Users\sdabk\AppData\Local\ms-playwright\webkit-2359\Playwright.exe
╔════════════════════════════════════════════════════════════╗
║ Looks like Playwright was just installed or updated.       ║
║ Please run the following command to download new browsers: ║
║                                                            ║
║     npx playwright install                                 ║
║                                                            ║
║ <3 Playwright Team                                         ║
╚════════════════════════════════════════════════════════════╝
```