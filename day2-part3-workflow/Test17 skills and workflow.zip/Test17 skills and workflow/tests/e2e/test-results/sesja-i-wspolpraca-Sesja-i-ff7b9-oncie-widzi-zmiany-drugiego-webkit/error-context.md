# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: sesja-i-wspolpraca.spec.ts >> Sesja i współpraca wielu użytkowników >> dwóch użytkowników na tym samym koncie widzi zmiany drugiego
- Location: tests\sesja-i-wspolpraca.spec.ts:10:7

# Error details

```
Error: browserType.launch: Executable doesn't exist at C:\Users\sdabk\AppData\Local\ms-playwright\webkit-2359\Playwright.exe
╔════════════════════════════════════════════════════════════╗
║ Looks like Playwright was just installed or updated.       ║
║ Please run the following command to download new browsers: ║
║                                                            ║
║     npx playwright install                                 ║
║                                                            ║
║ <3 Playwright Team                                         ║
╚════════════════════════════════════════════════════════════╝
```